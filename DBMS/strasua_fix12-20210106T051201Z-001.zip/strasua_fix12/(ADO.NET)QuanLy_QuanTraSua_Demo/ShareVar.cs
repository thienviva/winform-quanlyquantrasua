﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    class ShareVar
    {
        public static string MaNQL_TK;
        public static string TenTK_TK;
        public static bool setNV = false;
        public static int MaKH_Sigin;
        public static int MaHD_Mua;
    }
}
