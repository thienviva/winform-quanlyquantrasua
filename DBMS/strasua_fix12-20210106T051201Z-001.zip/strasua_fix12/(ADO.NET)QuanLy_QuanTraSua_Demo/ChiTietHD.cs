﻿using _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    public partial class ChiTietHD : Form
    {
        private Form_Login frm_Login;
        private string MA;

        DataTable dtMenu = null;
        DataTable dtNV = null;
        DataTable dtKH = null;
        DataTable dtQL = null;
        DataTable dtHD = null;
        DataTable dtCTHD = null;


        BLAccount_QL dbQL;
        BLAccount_NV dbNV;
        BLAccount_KH dbKH = new BLAccount_KH();
        public ChiTietHD()
        {
            InitializeComponent();
        }
        public void getForm(Form_Login frmLogin, string Ma, string id, string pass)
        {
            frm_Login = frmLogin;
            MA = Ma;

            dbQL = new BLAccount_QL(id, pass);
            dbNV = new BLAccount_NV(id, pass);
        }

        private void plQLHD_Paint(object sender, PaintEventArgs e)
        {

        }

        void LoadData()
        {
            try
            {
                lbMahd.Text = ShareVar.MaHD_Mua.ToString();
                lbMaKH.Text = ShareVar.MaKH_Sigin.ToString();
                //Lấy Menu
                //dtCTHD = new DataTable();
                //dtCTHD.Clear();
                //DataSet ds = dbQL.DSCTHoaDon(ShareVar.MaKH_Sigin);
                //dtCTHD = ds.Tables[0];
                //// Đưa dữ liệu lên DataGridView
                //dgvCTHD.DataSource = dtCTHD;
                //// Thay đổi độ rộng cột
                //dgvCTHD.AutoResizeColumns();

                dtCTHD = new DataTable();
                dtCTHD.Clear();
                DataSet dsCTHD = dbKH.DSCTHoaDon(int.Parse(lbMahd.Text));
                dtCTHD = dsCTHD.Tables[0];
                dgvCTHD.DataSource = dtCTHD;
                dgvCTHD.AutoResizeColumns();

                //dgvNV_CellClick(null, null);
                //dgvMenu_CellClick(null, null);
            }
            catch (SqlException)
            {
                MessageBox.Show("Không lấy được nội dung trong table . Lỗi rồi!!!");
            }
        }

        private void ChiTietHD_Load(object sender, EventArgs e)
        {
            LoadData();
        }
    }
}
