﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    public partial class Form_Management : Form
    {
        private Form_Login frm_Login;
        private string MA;

        DataTable dtMenu = null;
        DataTable dtNV = null;
        DataTable dtKH = null;
        DataTable dtQL = null;
        DataTable dtHD = null;

        BLAccount_QL dbQL;
        BLAccount_NV dbNV;
        BLAccount_KH dbKH = new BLAccount_KH();

        //các biến bool
        bool Them;
        bool Sua;
        bool TimMa;
        bool TimGia;
        bool TimTen;
        bool TimChuc;
        bool TimSDT;
        bool TimDiaChi;
        bool TimCapBac;
        bool TimLuong;
        bool TimTongCT;

        //biến dùng cho hàm search
        string style, var;

        string err;
        public Form_Management()
        {
            InitializeComponent();
        }
        public void getForm(Form_Login frmLogin, string Ma, string id, string pass)
        {
            frm_Login = frmLogin;
            MA = Ma;

            dbQL = new BLAccount_QL(id, pass);
            dbNV = new BLAccount_NV(id, pass);
        }

        private void Form_Management_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm_Login.LoadData();
            frm_Login.Show();
            ShareVar.setNV = false;
        }

        void LoadData()
        {
            try
            {
                //Lấy Menu
                dtMenu = new DataTable();
                dtMenu.Clear();
                DataSet ds = dbNV.LayMenu();
                dtMenu = ds.Tables[0];

                //Lấy thông tin nhân viên
                dtNV = new DataTable();
                dtNV.Clear();
                DataSet dsNV = dbNV.LayNV();
                dtNV = dsNV.Tables[0];

                //Lấy thông tin Khách hàng
                dtKH = new DataTable();
                dtKH.Clear();
                DataSet dsKH = dbKH.LayKH();
                dtKH = dsKH.Tables[0];

                // Đưa dữ liệu lên DataGridView
                dgvNV.DataSource = dtNV;
                dgvKH.DataSource = dtKH;
                dgvMenu.DataSource = dtMenu;

                // Thay đổi độ rộng cột
                dgvNV.AutoResizeColumns();
                dgvKH.AutoResizeColumns();
                dgvMenu.AutoResizeColumns();

                //dgvNV_CellClick(null, null);
                //dgvMenu_CellClick(null, null);

                if (ShareVar.setNV == true)
                {
                    plControl.Enabled = false;
                    plQLtKQL.Enabled = false;
                    plQLNV.Enabled = false;
                }
                else
                {
                    plControl.Enabled = true;
                    plQLtKQL.Enabled = true;
                    plQLNV.Enabled = true;
                }    

                //
                plInfo.Enabled = false;
                plInfoM.Enabled = false;
                plInfoK.Enabled = false;
            }
            catch (SqlException)
            {
                MessageBox.Show("Không lấy được nội dung trong table . Lỗi rồi!!!");
            }
        }

        private void Form_Management_Load(object sender, EventArgs e)
        {
            LoadData();
            plSearch.Enabled = false;
            btnLuu.Enabled = false;
            plSearchM.Enabled = false;
            btnLuuM.Enabled = false;
            plSearchK.Enabled = false;
            btnLuuK.Enabled = false;
            plLuong.Enabled = false;
            lbMaNQL.Text = ShareVar.MaNQL_TK;
            blTenTK_NQL.Text = ShareVar.TenTK_TK;
        }

        private void dgvNV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Thứ tự dòng hiện hành
            int r = dgvNV.CurrentCell.RowIndex;
            txtHoTen.Text = dgvNV.Rows[r].Cells[1].Value.ToString();
            txtEmail.Text = dgvNV.Rows[r].Cells[2].Value.ToString();
            txtTuoi.Text = dgvNV.Rows[r].Cells[3].Value.ToString();
            txtChucVu.Text = dgvNV.Rows[r].Cells[4].Value.ToString();
            txtSDT.Text = dgvNV.Rows[r].Cells[5].Value.ToString();
            txtDiaChi.Text = dgvNV.Rows[r].Cells[6].Value.ToString();
            txtMaCN.Text = dgvNV.Rows[r].Cells[7].Value.ToString();
            txtLuong.Text = dgvNV.Rows[r].Cells[8].Value.ToString();           
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            plSearch.Enabled = !plSearch.Enabled;
            plInfo.Enabled = plSearch.Enabled;

            btnThem.Enabled = btnSua.Enabled = btnXoa.Enabled = !plSearch.Enabled;
            btnLuu.Enabled = txtLuong.Enabled = false;

            //
            radChucVu.Checked = plSearch.Enabled;
            radDiaChi.Checked = plSearch.Enabled;
            radSDT.Checked = plSearch.Enabled;
            radHoTen.Checked = plSearch.Enabled;
            radioButton1.Checked = plSearch.Enabled;
            //reset text
            txtHoTen.ResetText();
            txtEmail.ResetText();
            txtTuoi.ResetText();
            txtChucVu.ResetText();
            txtDiaChi.ResetText();
            txtSDT.ResetText();
            txtMaCN.ResetText();
            txtLuong.ResetText();

            //focus vào họ tên
            txtHoTen.Focus();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            Them = true;
            Sua = false;
            btnLuu.Enabled = true;
            plInfo.Enabled = true;
            txtLuong.Enabled = true;

            //reset toàn bộ text
            txtHoTen.ResetText();
            txtEmail.ResetText();
            txtTuoi.ResetText();
            txtChucVu.ResetText();
            txtDiaChi.ResetText();
            txtSDT.ResetText();
            txtMaCN.ResetText();
            txtLuong.ResetText();

            //focus ô Tên NV
            txtHoTen.Focus();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            Sua = true;
            Them = false;
            btnLuu.Enabled = true;
            plInfo.Enabled = true;
            txtLuong.Enabled = true;
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn có chắc muốn xóa!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dlr == DialogResult.OK)
            {
                int r = dgvNV.CurrentCell.RowIndex;
                string manv = dgvNV.Rows[r].Cells[0].Value.ToString();
                dbNV.XoaNV(ref err, manv);
            }
            LoadData();
        }

        private void btnLuu_Click(object sender, EventArgs e)
        {
            if (Them)
            {
                //tự tạo mã NV
                int manv ;
                int count = dtNV.Rows.Count + 1;
                manv = 1000 + count;
                //if (count < 10)
                //{
                //    manv = manv + "0" + count.ToString();
                //}
                //else
                //{
                //    manv += count.ToString();
                //}

                dbNV.ThemNV(manv, txtHoTen.Text, txtEmail.Text, int.Parse(txtTuoi.Text), txtChucVu.Text, txtSDT.Text, txtDiaChi.Text, int.Parse(txtMaCN.Text), int.Parse(txtLuong.Text), ref err);
            }
            else if (Sua)
            {
                int r = dgvNV.CurrentCell.RowIndex;
                int manv = (int)dgvNV.Rows[r].Cells[0].Value;
                dbNV.CapNhatNV(manv, txtHoTen.Text, txtEmail.Text, int.Parse(txtTuoi.Text), txtChucVu.Text, txtSDT.Text, txtDiaChi.Text, int.Parse(txtMaCN.Text), int.Parse(txtLuong.Text), ref err);
            }
            MessageBox.Show("Đã lưu!");
            LoadData();
        }

        private void radHoTen_CheckedChanged(object sender, EventArgs e)
        {
            TimTen = true;
            TimLuong = TimChuc = TimDiaChi = TimSDT = false;

            txtHoTen.Enabled = true;
            plLuong.Enabled = txtEmail.Enabled = txtTuoi.Enabled = txtMaCN.Enabled = txtChucVu.Enabled = txtDiaChi.Enabled = txtSDT.Enabled = !radHoTen.Checked;

            txtHoTen.Focus();
        }

        private void radChucVu_CheckedChanged(object sender, EventArgs e)
        {
            TimChuc = true;
            TimLuong = TimTen = TimDiaChi = TimSDT = false;

            txtChucVu.Enabled = true;
            plLuong.Enabled = txtEmail.Enabled = txtTuoi.Enabled = txtMaCN.Enabled = txtDiaChi.Enabled = txtHoTen.Enabled = txtSDT.Enabled = !radChucVu.Checked;

            txtChucVu.Focus();
        }

        private void radDiaChi_CheckedChanged(object sender, EventArgs e)
        {
            TimDiaChi = true;
            TimLuong = TimChuc = TimTen = TimSDT = false;

            txtDiaChi.Enabled = true;
            plLuong.Enabled = txtEmail.Enabled = txtTuoi.Enabled = txtMaCN.Enabled = txtChucVu.Enabled = txtHoTen.Enabled = txtSDT.Enabled = !radDiaChi.Checked;

            txtDiaChi.Focus();
        }

        private void radSDT_CheckedChanged(object sender, EventArgs e)
        {
            TimSDT = true;
            TimLuong = TimChuc = TimDiaChi = TimTen = false;

            txtSDT.Enabled = true;
            plLuong.Enabled = txtEmail.Enabled = txtTuoi.Enabled = txtMaCN.Enabled = txtChucVu.Enabled = txtHoTen.Enabled = txtDiaChi.Enabled = !radSDT.Checked;

            txtSDT.Focus();
        }

        private void pbReload_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dgvMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Thứ tự dòng hiện hành
            int r = dgvMenu.CurrentCell.RowIndex;
            txtMaMon.Text = dgvMenu.Rows[r].Cells[0].Value.ToString();
            txtMaLoai.Text = dgvMenu.Rows[r].Cells[1].Value.ToString();
            txtTenMon.Text = dgvMenu.Rows[r].Cells[2].Value.ToString();
            txtGia.Text = dgvMenu.Rows[r].Cells[3].Value.ToString();
            txtsldb.Text = dgvMenu.Rows[r].Cells[4].Value.ToString();
        }

        private void btnThemM_Click(object sender, EventArgs e)
        {
            Them = true;
            Sua = false;
            btnLuuM.Enabled = true;
            plInfoM.Enabled = true;
            txtGia.Enabled = true;

            //reset toàn bộ text
            txtMaMon.ResetText();
            txtMaLoai.ResetText();
            txtTenMon.ResetText();
            txtGia.ResetText();
            txtsldb.ResetText();
            txtGia.Enabled = false;
            //focus ô Tên NV
            txtMaMon.Focus();
        }

        private void btnSuaM_Click(object sender, EventArgs e)
        {
            Sua = true;
            Them = false;
            btnLuuM.Enabled = true;
            plInfoM.Enabled = true;
            txtGia.Enabled = true;
        }

        private void btnXoaM_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn có chắc muốn xóa!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dlr == DialogResult.OK)
            {
                int r = dgvMenu.CurrentCell.RowIndex;
                string mamon = dgvMenu.Rows[r].Cells[0].Value.ToString();
                dbNV.XoaMonAn(ref err, mamon);
            }
            LoadData();
        }

        private void btnLuuM_Click(object sender, EventArgs e)
        {
            if (Them)
            {
                dbNV.ThemMonAn(txtMaMon.Text, int.Parse(txtMaLoai.Text), txtTenMon.Text, int.Parse(txtMucGia.Text), int.Parse(txtsldb.Text), ref err);
            }
            else if (Sua)
            {
                int r = dgvMenu.CurrentCell.RowIndex;
                string mamon = dgvMenu.Rows[r].Cells[0].Value.ToString();
                dbNV.CapNhatMonAn(mamon, int.Parse(txtMaLoai.Text), txtTenMon.Text, int.Parse(txtMucGia.Text), int.Parse(txtsldb.Text), ref err);
            }
            MessageBox.Show("Đã lưu!");
            LoadData();
        }

        private void radMaMon_CheckedChanged(object sender, EventArgs e)
        {
            TimMa = true;
            TimTen = TimGia = false;

            txtMaMon.Enabled = true;
            txtMaLoai.Enabled = txtsldb.Enabled = txtTenMon.Enabled = txtGia.Enabled = !radMaMon.Checked;

            txtMaMon.Focus();
        }

        private void radTenMon_CheckedChanged(object sender, EventArgs e)
        {
            TimTen = true;
            TimMa = TimGia = false;

            txtTenMon.Enabled = true;
            txtMaLoai.Enabled = txtsldb.Enabled = txtMaMon.Enabled = txtGia.Enabled = !radTenMon.Checked;

            txtTenMon.Focus();
        }

        private void radGia_CheckedChanged(object sender, EventArgs e)
        {
            TimGia = true;
            TimMa = TimTen = false;

            plMucGia.Enabled = radGia.Checked;
            plInfoM.Enabled = !plMucGia.Enabled;
            trbMucGia.Value = 0;
        }

        private void btnTimM_Click(object sender, EventArgs e)
        {
            plSearchM.Enabled = !plSearchM.Enabled;
            plInfoM.Enabled = plSearchM.Enabled;

            btnThemM.Enabled = btnSuaM.Enabled = btnXoaM.Enabled = !plSearchM.Enabled;
            btnLuuM.Enabled = txtGia.Enabled = false;

            //
            radTenMon.Checked = plSearchM.Enabled;
            radGia.Checked = plSearchM.Enabled;
            radMaMon.Checked = plSearchM.Enabled;

            //reset text
            txtMaMon.ResetText();
            txtMaLoai.ResetText();
            txtTenMon.ResetText();
            txtGia.ResetText();
            txtsldb.ResetText();
            txtGia.Enabled = false;

            //focus vào họ tên
            txtMaMon.Focus();
        }

        private void pbReloadM_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void trbMucGia_Scroll(object sender, EventArgs e)
        {
            txtMucGia.Text = (trbMucGia.Value * 1000).ToString();
        }

        private void btnSearchM_Click(object sender, EventArgs e)
        {
            DataTable dtTemp = new DataTable();
            if (TimMa)
            {
                style = "MaMon";
                var = txtMaMon.Text;
            }
            else if (TimTen)
            {
                style = "TenMon";
                var = txtTenMon.Text;
            }
            else if (TimGia)
            {
                var = txtMucGia.Text;
            }

            if (!TimGia)
            {
                dtTemp.Clear();
                DataSet dstemp = dbNV.TimMonAn(style, var);
                dtTemp = dstemp.Tables[0];
            }
            else
            {
                dtTemp.Clear();
                DataSet dstemp = dbNV.TimMonAn_Gia(int.Parse(var));
                dtTemp = dstemp.Tables[0];
            }

            if (dtTemp.Rows.Count == 0) MessageBox.Show("Không tìm thấy!");
            else
            {
                // Đưa dữ liệu lên DataGridView
                dgvMenu.DataSource = dtTemp;
                // Thay đổi độ rộng cột
                dgvMenu.AutoResizeColumns();

                dgvMenu_CellClick(null, null);

                //reset text
                txtMaMon.ResetText();
                txtMaLoai.ResetText();
                txtTenMon.ResetText();
                txtGia.ResetText();
                txtsldb.ResetText();
                txtGia.Enabled = false;
            }
        }

        private void dgvNV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvKH_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Thứ tự dòng hiện hành
            int r = dgvKH.CurrentCell.RowIndex;
            txtTenKH.Text = dgvKH.Rows[r].Cells[1].Value.ToString();
            txtEmailKH.Text = dgvKH.Rows[r].Cells[2].Value.ToString();
            txtTuoiKH.Text = dgvKH.Rows[r].Cells[3].Value.ToString();
            txtSDTKH.Text = dgvKH.Rows[r].Cells[4].Value.ToString();
            txtDiaChiKH.Text = dgvKH.Rows[r].Cells[5].Value.ToString();
            txtChiTieu.Text = dgvKH.Rows[r].Cells[6].Value.ToString();
            txtCapBac.Text = dgvKH.Rows[r].Cells[7].Value.ToString();
        }

        private void dgvKH_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnTim_NV_theoCN_Click(object sender, EventArgs e)
        {
            DataTable dtTemp = new DataTable();
            int search = 0;
            search = Convert.ToInt32(cbHien_NV_CN.Text);
            dtTemp.Clear();
            DataSet dstemp = dbQL.TimNV_chiNhanh(search);
            DataSet Tong = dbQL.Tinh_TongLuongCN(search);
            DataSet AVG = dbQL.Tinh_LuongTB_CN(search);
            dtTemp = dstemp.Tables[0];

            if (dtTemp.Rows.Count == 0) MessageBox.Show("Không tìm thấy!");
            else
            {
                // Đưa dữ liệu lên DataGridView
                dgvNV.DataSource = dtTemp;
                // Thay đổi độ rộng cột
                dgvNV.AutoResizeColumns();

                dgvNV_CellClick(null, null);

                //reset text
                txtHoTen.ResetText();
                txtEmail.ResetText();
                txtTuoi.ResetText();
                txtChucVu.ResetText();
                txtDiaChi.ResetText();
                txtSDT.ResetText();
                txtMaCN.ResetText();
                txtLuong.ResetText();
            }
            txtTongLuongCN.Text = Tong.Tables[0].Rows[0][0].ToString();
            txtAVGLuongCN.Text = AVG.Tables[0].Rows[0][0].ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn có chắc muốn xóa!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dlr == DialogResult.OK)
            {
                int r = dgvKH.CurrentCell.RowIndex;
                string mamon = dgvKH.Rows[r].Cells[0].Value.ToString();
                dbKH.XoaKH(ref err, mamon);
            }
            LoadData();
        }

        private void btnThemK_Click(object sender, EventArgs e)
        {
            Them = true;
            Sua = false;
            btnLuuK.Enabled = true;
            plInfoK.Enabled = true;


            //reset toàn bộ text
            txtTenKH.ResetText();
            txtEmailKH.ResetText();
            txtTuoiKH.ResetText();
            txtDiaChiKH.ResetText();
            txtSDTKH.ResetText();
            txtChiTieu.ResetText();
            txtCapBac.ResetText();

            //focus ô Tên NV
            txtTenKH.Focus();
            txtChiTieu.Enabled = false;
            txtCapBac.Enabled = false;
        }

        private void btnSuaK_Click(object sender, EventArgs e)
        {
            Sua = true;
            Them = false;
            btnLuuK.Enabled = true;
            plInfoK.Enabled = true;
            txtChiTieu.Enabled = false;
            txtCapBac.Enabled = false;
            //txtGia.Enabled = true;
        }

        private void btnLuuK_Click(object sender, EventArgs e)
        {
            if (Them)
            {
                //tự tạo mã NV
                int makh;
                int count = dtKH.Rows.Count + 1;
                makh = count;
                //if (count < 10)
                //{
                //    manv = manv + "0" + count.ToString();
                //}
                //else
                //{
                //    manv += count.ToString();
                //}

                dbKH.ThemKH(makh, txtTenKH.Text, txtEmailKH.Text, int.Parse(txtTuoiKH.Text), txtSDTKH.Text, txtDiaChiKH.Text, 0, 1, ref err);
            }
            else if (Sua)
            {
                int r = dgvKH.CurrentCell.RowIndex;
                int makh = (int)dgvKH.Rows[r].Cells[0].Value;
                dbKH.CapNhatKH(makh, txtTenKH.Text, txtEmailKH.Text, int.Parse(txtTuoiKH.Text), txtSDTKH.Text, txtDiaChiKH.Text, ref err);
            }
            MessageBox.Show("Đã lưu!");
            LoadData();
        }

        private void btnTimKiemK_Click(object sender, EventArgs e)
        {
            plSearchK.Enabled = !plSearchK.Enabled;
            plInfoK.Enabled = plSearchK.Enabled;

            btnThemK.Enabled = btnSuaK.Enabled = btnXoaK.Enabled = !plSearch.Enabled;
            btnLuuK.Enabled = false;

            //
            radTenKH.Checked = plSearch.Enabled;
            radCapBac.Checked = plSearch.Enabled;
            radDiaChiKH.Checked = plSearch.Enabled;
            radSDT_KH.Checked = plSearch.Enabled;
            radTongCT.Checked = plSearch.Enabled;
            //reset text
            txtTenKH.ResetText();
            txtEmailKH.ResetText();
            txtTuoiKH.ResetText();
            txtDiaChiKH.ResetText();
            txtSDTKH.ResetText();
            txtChiTieu.ResetText();
            txtCapBac.ResetText();

            //focus vào họ tên
            txtTenKH.Focus();
        }

        private void radTenKH_CheckedChanged(object sender, EventArgs e)
        {
            TimTen = true;
            TimTongCT = TimCapBac = TimDiaChi = TimSDT = false;

            txtTenKH.Enabled = true;
            plscroll_KH.Enabled = txtEmailKH.Enabled = txtTuoiKH.Enabled = txtDiaChiKH.Enabled = txtSDTKH.Enabled = txtChiTieu.Enabled = txtCapBac.Enabled = !radTenKH.Checked;

            txtTenKH.Focus();
        }

        private void radCapBac_CheckedChanged(object sender, EventArgs e)
        {
            TimCapBac = true;
            TimTongCT = TimTen = TimDiaChi = TimSDT = false;

            txtCapBac.Enabled = true;
            plscroll_KH.Enabled = txtEmailKH.Enabled = txtTuoiKH.Enabled = txtDiaChiKH.Enabled = txtSDTKH.Enabled = txtChiTieu.Enabled = txtTenKH.Enabled = !radCapBac.Checked;

            txtCapBac.Focus();
        }

        private void radDiaChiKH_CheckedChanged(object sender, EventArgs e)
        {
            TimDiaChi = true;
            TimTongCT = TimCapBac = TimTen = TimSDT = false;

            txtDiaChiKH.Enabled = true;
            plscroll_KH.Enabled = txtEmailKH.Enabled = txtTuoiKH.Enabled = txtTenKH.Enabled = txtSDTKH.Enabled = txtChiTieu.Enabled = txtCapBac.Enabled = !radDiaChiKH.Checked;

            txtDiaChiKH.Focus();
        }

        private void radSDT_KH_CheckedChanged(object sender, EventArgs e)
        {
            TimSDT = true;
            TimTongCT = TimCapBac = TimDiaChi = TimTen = false;

            txtSDTKH.Enabled = true;
            plscroll_KH.Enabled = txtEmailKH.Enabled = txtTuoiKH.Enabled = txtDiaChiKH.Enabled = txtTenKH.Enabled = txtChiTieu.Enabled = txtCapBac.Enabled = !radSDT_KH.Checked;

            txtSDTKH.Focus();
        }

        private void btnSearchK_Click_1(object sender, EventArgs e)
        {
            DataTable dtTemp = new DataTable();
            if (TimTen)
            {
                style = "TenKH";
                var = txtTenKH.Text;
            }
            else if (TimCapBac)
            {
                style = "CapBac";
                var = txtCapBac.Text;
            }
            else if (TimDiaChi)
            {
                style = "DiaChi";
                var = txtDiaChiKH.Text;
            }
            else if (TimSDT)
            {
                style = "SDT";
                var = txtSDTKH.Text;
            }
            else if (TimTongCT)
            {
                style = "TongCT";
                var = txtMucChiTieu.Text;
            }

            dtTemp.Clear();
            DataSet dstemp = dbKH.TimKH(style, var);
            dtTemp = dstemp.Tables[0];

            if (dtTemp.Rows.Count == 0) MessageBox.Show("Không tìm thấy!");
            else
            {
                // Đưa dữ liệu lên DataGridView
                dgvKH.DataSource = dtTemp;
                // Thay đổi độ rộng cột
                dgvKH.AutoResizeColumns();

                dgvKH_CellClick(null, null);

                //reset text
                txtTenKH.ResetText();
                txtEmailKH.ResetText();
                txtTuoiKH.ResetText();
                txtDiaChiKH.ResetText();
                txtSDTKH.ResetText();
                txtChiTieu.ResetText();
                txtCapBac.ResetText();
            }
        }

        private void trbMucLuong_Scroll(object sender, EventArgs e)
        {
            txtMucLuong.Text = (trbMucLuong.Value * 1000000).ToString();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            TimLuong = true;
            TimTen = TimDiaChi = TimSDT = TimChuc= false;

            plLuong.Enabled = true;
            txtChucVu.Enabled = txtEmail.Enabled = txtTuoi.Enabled = txtMaCN.Enabled = txtDiaChi.Enabled = txtHoTen.Enabled = txtSDT.Enabled = !radioButton1.Checked;

            trbMucLuong.Value = 0;
        }

        private void trbMucChiTieu_Scroll(object sender, EventArgs e)
        {
            txtMucChiTieu.Text = (trbMucChiTieu.Value * 500000).ToString();
        }

        private void radTongCT_CheckedChanged(object sender, EventArgs e)
        {
            TimTongCT = true;
            TimTen = TimCapBac = TimDiaChi = TimSDT = false;

            plscroll_KH.Enabled = true;
            txtTenKH.Enabled= txtEmailKH.Enabled = txtTuoiKH.Enabled = txtDiaChiKH.Enabled = txtSDTKH.Enabled = txtChiTieu.Enabled = txtCapBac.Enabled = !radTongCT.Checked;
            trbMucChiTieu.Value = 0;
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void QLMENU_Click(object sender, EventArgs e)
        {

        }

        private void btnXoaNguoiQuanLy_Click(object sender, EventArgs e)
        {
            
        }

        private void btnXoaNguoiQuanLy_Click_1(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn có chắc muốn xóa!", "Thông báo", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (dlr == DialogResult.OK)
            {
                int r = dgvNV.CurrentCell.RowIndex;
                dbQL.XoaQL(ref err, Convert.ToInt32(ShareVar.MaNQL_TK));
                frm_Login.LoadData();
                frm_Login.Show();
                this.Close();
            }
            LoadData();
        }

        private void top5kh_Click(object sender, EventArgs e)
        {
            DataTable dtTemp = new DataTable();
            dtTemp.Clear();
            DataSet dstemp = dbKH.Top5KH();
            dtTemp = dstemp.Tables[0];

            if (dtTemp.Rows.Count == 0) MessageBox.Show("Không tìm thấy!");
            else
            {
                // Đưa dữ liệu lên DataGridView
                dgvKH.DataSource = dtTemp;
                // Thay đổi độ rộng cột
                dgvKH.AutoResizeColumns();

                dgvKH_CellClick(null, null);

                //reset text
                txtTenKH.ResetText();
                txtEmailKH.ResetText();
                txtTuoiKH.ResetText();
                txtDiaChiKH.ResetText();
                txtSDTKH.ResetText();
                txtChiTieu.ResetText();
                txtCapBac.ResetText();
            }
        }

        private void top5mon_Click(object sender, EventArgs e)
        {
            DataTable dtTemp = new DataTable();
            dtTemp.Clear();
            DataSet dstemp = dbQL.Top5Mon();
            dtTemp = dstemp.Tables[0];

            if (dtTemp.Rows.Count == 0) MessageBox.Show("Không tìm thấy!");
            else
            {
                // Đưa dữ liệu lên DataGridView
                dgvMenu.DataSource = dtTemp;
                // Thay đổi độ rộng cột
                dgvMenu.AutoResizeColumns();

                dgvMenu_CellClick(null, null);

                //reset text
                txtMaMon.ResetText();
                txtMaLoai.ResetText();
                txtTenMon.ResetText();
                txtGia.ResetText();
                txtsldb.ResetText();
                txtGia.Enabled = false;
            }
        }

        private void pbReloadKH_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnHD_Click(object sender, EventArgs e)
        {
            //Lấy thông tin Khách hàng
            dtHD = new DataTable();
            dtHD.Clear();
            DataSet dsHD = dbQL.DSHoaDon();
            dtHD = dsHD.Tables[0];
            dgvHD.DataSource = dtHD;
            dgvHD.AutoResizeColumns();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable dtTemp = new DataTable();
            if (TimTen)
            {
                style = "TenNV";
                var = txtHoTen.Text;
            }
            else if (TimChuc)
            {
                style = "ChucVu";
                var = txtChucVu.Text;
            }
            else if (TimDiaChi)
            {
                style = "DiaChi";
                var = txtDiaChi.Text;
            }
            else if (TimSDT)
            {
                style = "SDT";
                var = txtSDT.Text;
            }
            else if(TimLuong)
            {
                style = "Luong";
                var = txtMucLuong.Text;
            }

            dtTemp.Clear();
            DataSet dstemp = dbQL.TimNV(style, var);
            dtTemp = dstemp.Tables[0];

            if (dtTemp.Rows.Count == 0) MessageBox.Show("Không tìm thấy!");
            else
            {
                // Đưa dữ liệu lên DataGridView
                dgvNV.DataSource = dtTemp;
                // Thay đổi độ rộng cột
                dgvNV.AutoResizeColumns();

                dgvNV_CellClick(null, null);

                //reset text
                txtHoTen.ResetText();
                txtEmail.ResetText();
                txtTuoi.ResetText();
                txtChucVu.ResetText();
                txtDiaChi.ResetText();
                txtSDT.ResetText();
                txtMaCN.ResetText();
                txtLuong.ResetText();
            }
        }
    }
}
