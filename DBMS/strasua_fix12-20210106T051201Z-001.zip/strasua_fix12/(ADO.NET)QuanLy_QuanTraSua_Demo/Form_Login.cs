﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer;
using System.Windows.Forms;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    public partial class Form_Login : Form
    {
        private Form_Signin frm_Signin;
        private Form_Menu frm_Menu;
        private Form_Management frm_Management;

        bool beQL;
        bool beNV;
        bool beKH;

        DataTable dtQL = null;
        DataTable dtNV = null;
        DataTable dtKH = null;

        BLAccount dbA = new BLAccount();

        public Form_Login()
        {
            InitializeComponent();
        }
        public void LoadData()
        {
            try
            {
                //Lấy account quản lý
                dtQL = new DataTable();
                dtQL.Clear();
                DataSet dsAQL = dbA.LayAQL();
                dtQL = dsAQL.Tables[0];

                //Lấy account nhân viên
                dtNV = new DataTable();
                dtNV.Clear();
                DataSet dsANV = dbA.LayANV();
                dtNV = dsANV.Tables[0];

                //Lấy account khách hàng
                dtKH = new DataTable();
                dtKH.Clear();
                DataSet dsAKH = dbA.LayAKH();
                dtKH = dsAKH.Tables[0];

                if (beQL)
                {
                    // Xóa trống các đối tượng trong Panel
                    this.txtUserName.ResetText();
                    this.txtPassword.ResetText();
                    // Không cho thao tác trên các nút đăng ký
                    this.btnSignin.Enabled = false;
                }
                else if (beNV)
                {   
                    // Xóa trống các đối tượng trong Panel
                    this.txtUserName.ResetText();
                    this.txtPassword.ResetText();
                    // Không cho thao tác trên các nút đăng ký
                    this.btnSignin.Enabled = false;
                }
                else if (beKH)
                {
                    // Xóa trống các đối tượng trong Panel
                    this.txtUserName.ResetText();
                    this.txtPassword.ResetText();
                }
            }
            catch (SqlException)
            {
                MessageBox.Show("Không lấy được nội dung trong table. Lỗi rồi!!!");
            }
        }

        private void btnSignin_Click(object sender, EventArgs e)
        {
            frm_Signin = new Form_Signin();
            frm_Signin.getForm(this);
            frm_Signin.Show();
            this.Hide();
        }

        private void btnNV_Click(object sender, EventArgs e)
        {
            btnSignin.Enabled = false;
            beQL = false;
            beNV = true;
            beKH = false;
            btnNV.BackColor = Color.Red;
            btnKH.BackColor = DefaultBackColor;
            btnQL.BackColor = DefaultBackColor;
            txtUserName.ResetText();
            txtPassword.ResetText();
            txtUserName.Focus();
        }

        private void btnKH_Click(object sender, EventArgs e)
        {
            btnSignin.Enabled = true;
            beKH = true;
            beNV = false;
            btnKH.BackColor = Color.Red;
            btnNV.BackColor = DefaultBackColor;
            btnQL.BackColor = DefaultBackColor;
            txtUserName.ResetText();
            txtPassword.ResetText();
            txtUserName.Focus();
        }

        private void Form_Login_Load(object sender, EventArgs e)
        {
            LoadData();
            btnKH.PerformClick();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (beQL)
            {
                int i = 0;
                for (; i < dtQL.Rows.Count; i++)
                {
                    if (txtUserName.Text == dtQL.Rows[i][0].ToString() && txtPassword.Text == dtQL.Rows[i][1].ToString())
                    {
                        ShareVar.MaNQL_TK = dtQL.Rows[i][2].ToString();
                        ShareVar.TenTK_TK = dtQL.Rows[i][0].ToString();
                        frm_Management = new Form_Management();
                        frm_Management.getForm(this, dtQL.Rows[i][2].ToString(), txtUserName.Text.ToString(), txtPassword.Text.ToString());
                        frm_Management.Show();

                        this.Hide();
                        break;
                    }
                }
                if (i == dtQL.Rows.Count) MessageBox.Show("Tài khoản không đúng!");
                //frm_Management = new Form_Management();
                ////frm_Management.getForm(this, dtNV.Rows[i][2].ToString());
                //frm_Management.Show();
                //this.Hide();
            }
            else  if (beNV)
            {
                int i = 0;
                for (; i < dtNV.Rows.Count; i++)
                {
                    if (txtUserName.Text == dtNV.Rows[i][0].ToString() && txtPassword.Text == dtNV.Rows[i][1].ToString())
                    {
                        ShareVar.setNV = true;
                        frm_Management = new Form_Management();
                        frm_Management.getForm(this, dtNV.Rows[i][2].ToString(), txtUserName.Text.ToString(), txtPassword.Text.ToString());
                        frm_Management.Show();
                        this.Hide();
                        break;
                    }
                }
                if (i == dtNV.Rows.Count) MessageBox.Show("Tài khoản không đúng!");
                //frm_Management = new Form_Management();
                ////frm_Management.getForm(this, dtNV.Rows[i][2].ToString());
                //frm_Management.Show();
                //this.Hide();
            }
            else if (beKH)
            {
                int i = 0;
                for (; i < dtKH.Rows.Count; i++)
                {
                    if (txtUserName.Text == dtKH.Rows[i][0].ToString() && txtPassword.Text == dtKH.Rows[i][1].ToString())
                    {
                        frm_Menu = new Form_Menu();
                        frm_Menu.getForm(this, (int)dtKH.Rows[i][2]);
                        frm_Menu.Show();
                        this.Hide();
                        break;
                    }
                }
                if (i == dtKH.Rows.Count) MessageBox.Show("Tài khoản không đúng! Mời đăng kí!!");
            }
        }

        private void btnPass_Click(object sender, EventArgs e)
        {
            frm_Menu = new Form_Menu();
            frm_Menu.getForm(this, 0);
            frm_Menu.Show();
            this.Hide();
        }

        private void btnQL_Click(object sender, EventArgs e)
        {
            btnSignin.Enabled = false;
            beQL = true;
            beNV = true;
            beKH = false;
            btnQL.BackColor = Color.Red;
            btnNV.BackColor = DefaultBackColor;
            btnKH.BackColor = DefaultBackColor;
            txtUserName.ResetText();
            txtPassword.ResetText();
            txtUserName.Focus();
        }
    }
}
