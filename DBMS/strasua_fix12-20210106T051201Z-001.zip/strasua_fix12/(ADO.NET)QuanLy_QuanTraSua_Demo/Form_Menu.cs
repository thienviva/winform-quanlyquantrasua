﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    public partial class Form_Menu : Form
    {
        private Form_Login frm_Login;
        private Form_SuaThongTin frm_Sua;
        private int MAKH;

        DataTable dtMenu = null;
        DataTable dtKH = null;

        DataSet slhd;

        BLAccount_KH dbKH = new BLAccount_KH();

        string err;

        public Form_Menu()
        {
            InitializeComponent();
        }

        public void getForm(Form_Login frmLogin, int MaKH)
        {
            this.frm_Login = frmLogin;
            MAKH = MaKH;
            ShareVar.MaKH_Sigin = MaKH;
        }

        public void LoadData()
        {
            try
            {
                //Lấy Menu
                dtMenu = new DataTable();
                dtMenu.Clear();
                DataSet ds = dbKH.LayMenu();
                dtMenu = ds.Tables[0];

                //Lấy thông tin khách hàng
                dtKH = new DataTable();
                dtKH.Clear();
                DataSet dsKH = dbKH.LayKH();
                dtKH = dsKH.Tables[0];

                //Tạo list view hóa đơn
                livHoaDon.View = View.Details;
                livHoaDon.Columns.Add("Tên món", 140);
                livHoaDon.Columns.Add("SL", 30);
                livHoaDon.Columns.Add("Giá", 45);
                livHoaDon.GridLines = true;
                livHoaDon.FullRowSelect = true;

                txtTong.Text = "0";

                if (MAKH != 0)
                {
                    int i = 0;
                    while (i < dtKH.Rows.Count && (int)dtKH.Rows[i][0] != MAKH) i++;
                    txtHoTen.Text = dtKH.Rows[i][1].ToString();
                    txtRank.Text = dtKH.Rows[i][7].ToString();
                }

                // Đưa dữ liệu lên DataGridView
                dgvMenu.DataSource = dtMenu;
                // Thay đổi độ rộng cột
                dgvMenu.AutoResizeColumns();

                dgvMenu_CellClick(null, null);
            }
            catch (SqlException)
            {
                MessageBox.Show("Không lấy được nội dung trong table . Lỗi rồi!!!");
            }
        }

        private void Form_Menu_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm_Login.Show();
        }

        private void Form_Menu_Load(object sender, EventArgs e)
        {
            LoadData();
            if (MAKH == 0) btnChange.Enabled = false;
        }

        private void dgvMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            // Thứ tự dòng hiện hành
            int r = dgvMenu.CurrentCell.RowIndex;
            txtTenMon.Text = dgvMenu.Rows[r].Cells[2].Value.ToString();
            nuSoluong.Value = 1;
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            int i = 0;
            while (i < dtMenu.Rows.Count && dtMenu.Rows[i][2].ToString() != txtTenMon.Text) i++;
            //thêm item
            ListViewItem item = new ListViewItem();
            item.Text = txtTenMon.Text;
            item.SubItems.Add(nuSoluong.Value.ToString());
            item.SubItems.Add(dtMenu.Rows[i][3].ToString());
            livHoaDon.Items.Add(item);

            //tính tổng tiền
            int tong = int.Parse(txtTong.Text) + int.Parse(dtMenu.Rows[i][3].ToString()) * int.Parse(nuSoluong.Value.ToString());
            txtTong.Text = tong.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (livHoaDon.Items.Count == 0)
            {
                MessageBox.Show("Trong MENU không có món ăn nào !!");
                return;
            }
            if (livHoaDon.SelectedItems.Count == 0)
            {
                MessageBox.Show("Bạn hãy chọn món cần xóa");
                return;
            }

            //tính sl món ăn cùng loại bị xóa
            int sl = int.Parse(livHoaDon.Items[livHoaDon.SelectedIndices[0]].SubItems[1].Text);
            //lấy giá của món ăn
            int gia = int.Parse(livHoaDon.Items[livHoaDon.SelectedIndices[0]].SubItems[2].Text);
            //tính tổng tiền
            int tong = int.Parse(txtTong.Text) - sl * gia;
            txtTong.Text = tong.ToString();
            //xóa món ăn
            livHoaDon.Items.RemoveAt(livHoaDon.SelectedIndices[0]);
            if (livHoaDon.Items.Count != 0) livHoaDon.Items[0].Selected = true;

        }

        private void btnPay_Click(object sender, EventArgs e)
        {
            if (MAKH != 0)
            {
                int i = 0;
                while (i < dtKH.Rows.Count && (int)dtKH.Rows[i][0] != MAKH) i++;

                int tongchi = int.Parse(dtKH.Rows[i][6].ToString());
                int tong = tongchi + int.Parse(txtTong.Text);
                dbKH.CapNhatTien(MAKH, tong, ref err);

                int rank = tong / 1000000;
                if (rank != int.Parse(dtKH.Rows[i][7].ToString()))
                {
                    dbKH.CapNhatRank(MAKH, rank, ref err);
                }
                txtRank.Text = dtKH.Rows[i][7].ToString();

                //int khuyenmai = int.Parse(dtKH.Rows[i][6].ToString());
                //if (khuyenmai < 50)
                //{
                //    int km = rank * 5;
                //    dbKH.CapNhatKM(MAKH, km, ref err);
                //}
                slhd = new DataSet();
                slhd = dbKH.LayDSMaHD();
                int mahd = 0;
                int sl = slhd.Tables[0].Rows.Count + 1;
                mahd = sl;
                ShareVar.MaHD_Mua = mahd;
                dbKH = new BLAccount_KH();
                bool kq = dbKH.ThemHD(mahd, MAKH, 101, DateTime.Now.Date, int.Parse(txtTong.Text), ref err);
                for (int j = 0; j < livHoaDon.Items.Count; j++)
                {
                    DataSet LayMM = dbKH.LayMaMon(livHoaDon.Items[j].SubItems[0].Text);
                    string mamon = LayMM.Tables[0].Rows[0][0].ToString();
                    dbKH = new BLAccount_KH();
                    dbKH.ThemChiTiet_HD(mahd, mamon, int.Parse(livHoaDon.Items[j].SubItems[1].Text), int.Parse(livHoaDon.Items[j].SubItems[2].Text), ref err);
                }

            }
            ChiTietHD f = new ChiTietHD();
            f.Show();
            //MessageBox.Show("Đã thanh toán! Cảm ơn quý khách <3");
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            frm_Sua = new Form_SuaThongTin();
            frm_Sua.getForm(this, MAKH);
            frm_Sua.Show();
            this.Hide();
        }

        private void plDetail_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }
    }
}
