﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer;
using System.Windows.Forms;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    public partial class Form_Signin : Form
    {
        private int MAKH;
        private Form_Login frm_Login;

        DataTable dtKH = null;
        BLAccount_KH dbAKH = new BLAccount_KH();

        string err;
        public Form_Signin()
        {
            InitializeComponent();
        }

        public void getForm(Form_Login frmLogin)
        {
            this.frm_Login = frmLogin;
        }

        private void Form_Signin_FormClosed(object sender, FormClosedEventArgs e)
        {
            frm_Login.LoadData();
            frm_Login.Show();
        }
        void LoadData()
        {
            try
            {
                //Lấy account khách hàng
                dtKH = new DataTable();
                dtKH.Clear();
                DataSet dsAKH = dbAKH.LayAKH();
                dtKH = dsAKH.Tables[0];

                this.txtUserName.ResetText();
                this.txtPassword.ResetText();

                //Tạo tự động mã khách hàng
                int i = dtKH.Rows.Count + 1;
                MAKH = i;
                //if (i < 10)
                //{
                //    MAKH = "KH0" + i.ToString();
                //}
                //else
                //{
                //    MAKH = "KH" + i.ToString();
                //}
            }
            catch (SqlException)
            {
                MessageBox.Show("Không lấy được nội dung trong table. Lỗi rồi!!!");
            }
        }
        private void Form_Signin_Load(object sender, EventArgs e)
        {
            LoadData();
            txtUserName.Focus();
        }

        private void btnSignin_Click(object sender, EventArgs e)
        {
            try
            {
                BLAccount_KH bLAccount_KH = new BLAccount_KH();              
                bLAccount_KH.ThemKH(MAKH, txtHoTen.Text,txtEmail.Text,int.Parse(txtTuoi.Text), txtSDT.Text, txtDiaChi.Text,0,0, ref err);
                bLAccount_KH.ThemAKH(txtUserName.Text, txtPassword.Text, MAKH, ref err);
                // Thông báo
                LoadData();
                MessageBox.Show("Đã tạo tài khoản xong!");
            }
            catch (SqlException)
            {
                MessageBox.Show("Không thêm được. Lỗi rồi!");
            }
        }
    }
}
