﻿namespace _ADO.NET_QuanLy_QuanTraSua_Demo
{
    partial class Form_Management
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.QLMENU = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.top5mon = new System.Windows.Forms.Button();
            this.plMucGia = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.txtMucGia = new System.Windows.Forms.TextBox();
            this.trbMucGia = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvMenu = new System.Windows.Forms.DataGridView();
            this.plSearchM = new System.Windows.Forms.Panel();
            this.pbReloadM = new System.Windows.Forms.PictureBox();
            this.radGia = new System.Windows.Forms.RadioButton();
            this.radTenMon = new System.Windows.Forms.RadioButton();
            this.radMaMon = new System.Windows.Forms.RadioButton();
            this.btnSearchM = new System.Windows.Forms.Button();
            this.plControlM = new System.Windows.Forms.Panel();
            this.btnSuaM = new System.Windows.Forms.Button();
            this.btnTimM = new System.Windows.Forms.Button();
            this.btnLuuM = new System.Windows.Forms.Button();
            this.btnXoaM = new System.Windows.Forms.Button();
            this.btnThemM = new System.Windows.Forms.Button();
            this.plInfoM = new System.Windows.Forms.Panel();
            this.txtsldb = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtMaLoai = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtGia = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtTenMon = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtMaMon = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.QLNV = new System.Windows.Forms.TabPage();
            this.plLuong = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.txtMucLuong = new System.Windows.Forms.TextBox();
            this.trbMucLuong = new System.Windows.Forms.TrackBar();
            this.label29 = new System.Windows.Forms.Label();
            this.plQLNV = new System.Windows.Forms.Panel();
            this.txtAVGLuongCN = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtTongLuongCN = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.cbHien_NV_CN = new System.Windows.Forms.ComboBox();
            this.btnTim_NV_theoCN = new System.Windows.Forms.Button();
            this.plSearch = new System.Windows.Forms.Panel();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.pbReload = new System.Windows.Forms.PictureBox();
            this.radSDT = new System.Windows.Forms.RadioButton();
            this.radDiaChi = new System.Windows.Forms.RadioButton();
            this.radChucVu = new System.Windows.Forms.RadioButton();
            this.radHoTen = new System.Windows.Forms.RadioButton();
            this.btnSearch = new System.Windows.Forms.Button();
            this.plControl = new System.Windows.Forms.Panel();
            this.btnSua = new System.Windows.Forms.Button();
            this.btnTim = new System.Windows.Forms.Button();
            this.btnLuu = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnThem = new System.Windows.Forms.Button();
            this.plInfo = new System.Windows.Forms.Panel();
            this.txtMaCN = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTuoi = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtLuong = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvNV = new System.Windows.Forms.DataGridView();
            this.tabManager = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.top5kh = new System.Windows.Forms.Button();
            this.plscroll_KH = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.txtMucChiTieu = new System.Windows.Forms.TextBox();
            this.trbMucChiTieu = new System.Windows.Forms.TrackBar();
            this.label27 = new System.Windows.Forms.Label();
            this.plSearchK = new System.Windows.Forms.Panel();
            this.radTongCT = new System.Windows.Forms.RadioButton();
            this.pbReloadKH = new System.Windows.Forms.PictureBox();
            this.radSDT_KH = new System.Windows.Forms.RadioButton();
            this.radDiaChiKH = new System.Windows.Forms.RadioButton();
            this.radCapBac = new System.Windows.Forms.RadioButton();
            this.radTenKH = new System.Windows.Forms.RadioButton();
            this.btnSearchK = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnSuaK = new System.Windows.Forms.Button();
            this.btnTimKiemK = new System.Windows.Forms.Button();
            this.btnLuuK = new System.Windows.Forms.Button();
            this.btnXoaK = new System.Windows.Forms.Button();
            this.btnThemK = new System.Windows.Forms.Button();
            this.plInfoK = new System.Windows.Forms.Panel();
            this.txtEmailKH = new System.Windows.Forms.TextBox();
            this.txtCapBac = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtTuoiKH = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtChiTieu = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txtDiaChiKH = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtSDTKH = new System.Windows.Forms.TextBox();
            this.txtTenKH = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.dgvKH = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.plQLtKQL = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.blTenTK_NQL = new System.Windows.Forms.Label();
            this.lbMaNQL = new System.Windows.Forms.Label();
            this.btnXoaNguoiQuanLy = new System.Windows.Forms.Button();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dgvHD = new System.Windows.Forms.DataGridView();
            this.plQLHD = new System.Windows.Forms.Panel();
            this.label37 = new System.Windows.Forms.Label();
            this.btnHD = new System.Windows.Forms.Button();
            this.QLMENU.SuspendLayout();
            this.panel1.SuspendLayout();
            this.plMucGia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbMucGia)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMenu)).BeginInit();
            this.plSearchM.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReloadM)).BeginInit();
            this.plControlM.SuspendLayout();
            this.plInfoM.SuspendLayout();
            this.QLNV.SuspendLayout();
            this.plLuong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbMucLuong)).BeginInit();
            this.plQLNV.SuspendLayout();
            this.plSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReload)).BeginInit();
            this.plControl.SuspendLayout();
            this.plInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).BeginInit();
            this.tabManager.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.plscroll_KH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbMucChiTieu)).BeginInit();
            this.plSearchK.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReloadKH)).BeginInit();
            this.panel2.SuspendLayout();
            this.plInfoK.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKH)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.plQLtKQL.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).BeginInit();
            this.plQLHD.SuspendLayout();
            this.SuspendLayout();
            // 
            // QLMENU
            // 
            this.QLMENU.Controls.Add(this.panel1);
            this.QLMENU.Controls.Add(this.plMucGia);
            this.QLMENU.Controls.Add(this.dgvMenu);
            this.QLMENU.Controls.Add(this.plSearchM);
            this.QLMENU.Controls.Add(this.plControlM);
            this.QLMENU.Controls.Add(this.plInfoM);
            this.QLMENU.Location = new System.Drawing.Point(4, 34);
            this.QLMENU.Name = "QLMENU";
            this.QLMENU.Padding = new System.Windows.Forms.Padding(3);
            this.QLMENU.Size = new System.Drawing.Size(1198, 805);
            this.QLMENU.TabIndex = 1;
            this.QLMENU.Text = "Quản lý Menu";
            this.QLMENU.UseVisualStyleBackColor = true;
            this.QLMENU.Click += new System.EventHandler(this.QLMENU_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Control;
            this.panel1.Controls.Add(this.top5mon);
            this.panel1.Location = new System.Drawing.Point(794, 308);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(392, 86);
            this.panel1.TabIndex = 9;
            // 
            // top5mon
            // 
            this.top5mon.Location = new System.Drawing.Point(10, 16);
            this.top5mon.Name = "top5mon";
            this.top5mon.Size = new System.Drawing.Size(370, 54);
            this.top5mon.TabIndex = 6;
            this.top5mon.Text = "Top 5 món bán nhiều nhất";
            this.top5mon.UseVisualStyleBackColor = true;
            this.top5mon.Click += new System.EventHandler(this.top5mon_Click);
            // 
            // plMucGia
            // 
            this.plMucGia.BackColor = System.Drawing.SystemColors.Control;
            this.plMucGia.Controls.Add(this.label7);
            this.plMucGia.Controls.Add(this.txtMucGia);
            this.plMucGia.Controls.Add(this.trbMucGia);
            this.plMucGia.Controls.Add(this.label6);
            this.plMucGia.Location = new System.Drawing.Point(794, 400);
            this.plMucGia.Name = "plMucGia";
            this.plMucGia.Size = new System.Drawing.Size(392, 100);
            this.plMucGia.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(275, 66);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 26);
            this.label7.TabIndex = 4;
            this.label7.Text = "đồng";
            // 
            // txtMucGia
            // 
            this.txtMucGia.Enabled = false;
            this.txtMucGia.Location = new System.Drawing.Point(119, 63);
            this.txtMucGia.Name = "txtMucGia";
            this.txtMucGia.Size = new System.Drawing.Size(149, 34);
            this.txtMucGia.TabIndex = 3;
            // 
            // trbMucGia
            // 
            this.trbMucGia.Location = new System.Drawing.Point(119, 16);
            this.trbMucGia.Maximum = 50;
            this.trbMucGia.Name = "trbMucGia";
            this.trbMucGia.Size = new System.Drawing.Size(261, 56);
            this.trbMucGia.TabIndex = 2;
            this.trbMucGia.Scroll += new System.EventHandler(this.trbMucGia_Scroll);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 16);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 26);
            this.label6.TabIndex = 0;
            this.label6.Text = "Mức giá:";
            // 
            // dgvMenu
            // 
            this.dgvMenu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMenu.Location = new System.Drawing.Point(6, 6);
            this.dgvMenu.Name = "dgvMenu";
            this.dgvMenu.RowHeadersWidth = 51;
            this.dgvMenu.RowTemplate.Height = 24;
            this.dgvMenu.Size = new System.Drawing.Size(782, 694);
            this.dgvMenu.TabIndex = 7;
            this.dgvMenu.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMenu_CellClick);
            // 
            // plSearchM
            // 
            this.plSearchM.BackColor = System.Drawing.SystemColors.Control;
            this.plSearchM.Controls.Add(this.pbReloadM);
            this.plSearchM.Controls.Add(this.radGia);
            this.plSearchM.Controls.Add(this.radTenMon);
            this.plSearchM.Controls.Add(this.radMaMon);
            this.plSearchM.Controls.Add(this.btnSearchM);
            this.plSearchM.Location = new System.Drawing.Point(990, 506);
            this.plSearchM.Name = "plSearchM";
            this.plSearchM.Size = new System.Drawing.Size(196, 194);
            this.plSearchM.TabIndex = 6;
            // 
            // pbReloadM
            // 
            this.pbReloadM.Image = global::_ADO.NET_QuanLy_QuanTraSua_Demo.Properties.Resources.Reload;
            this.pbReloadM.Location = new System.Drawing.Point(142, 12);
            this.pbReloadM.Name = "pbReloadM";
            this.pbReloadM.Size = new System.Drawing.Size(42, 39);
            this.pbReloadM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReloadM.TabIndex = 10;
            this.pbReloadM.TabStop = false;
            this.pbReloadM.Click += new System.EventHandler(this.pbReloadM_Click);
            // 
            // radGia
            // 
            this.radGia.AutoSize = true;
            this.radGia.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radGia.Location = new System.Drawing.Point(14, 67);
            this.radGia.Name = "radGia";
            this.radGia.Size = new System.Drawing.Size(58, 23);
            this.radGia.TabIndex = 8;
            this.radGia.TabStop = true;
            this.radGia.Text = "Giá";
            this.radGia.UseVisualStyleBackColor = true;
            this.radGia.CheckedChanged += new System.EventHandler(this.radGia_CheckedChanged);
            // 
            // radTenMon
            // 
            this.radTenMon.AutoSize = true;
            this.radTenMon.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTenMon.Location = new System.Drawing.Point(14, 38);
            this.radTenMon.Name = "radTenMon";
            this.radTenMon.Size = new System.Drawing.Size(93, 23);
            this.radTenMon.TabIndex = 7;
            this.radTenMon.TabStop = true;
            this.radTenMon.Text = "Tên món";
            this.radTenMon.UseVisualStyleBackColor = true;
            this.radTenMon.CheckedChanged += new System.EventHandler(this.radTenMon_CheckedChanged);
            // 
            // radMaMon
            // 
            this.radMaMon.AutoSize = true;
            this.radMaMon.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radMaMon.Location = new System.Drawing.Point(14, 12);
            this.radMaMon.Name = "radMaMon";
            this.radMaMon.Size = new System.Drawing.Size(90, 23);
            this.radMaMon.TabIndex = 6;
            this.radMaMon.TabStop = true;
            this.radMaMon.Text = "Mã món";
            this.radMaMon.UseVisualStyleBackColor = true;
            this.radMaMon.CheckedChanged += new System.EventHandler(this.radMaMon_CheckedChanged);
            // 
            // btnSearchM
            // 
            this.btnSearchM.Location = new System.Drawing.Point(14, 147);
            this.btnSearchM.Name = "btnSearchM";
            this.btnSearchM.Size = new System.Drawing.Size(170, 39);
            this.btnSearchM.TabIndex = 5;
            this.btnSearchM.Text = "Tìm kiếm";
            this.btnSearchM.UseVisualStyleBackColor = true;
            this.btnSearchM.Click += new System.EventHandler(this.btnSearchM_Click);
            // 
            // plControlM
            // 
            this.plControlM.BackColor = System.Drawing.SystemColors.Control;
            this.plControlM.Controls.Add(this.btnSuaM);
            this.plControlM.Controls.Add(this.btnTimM);
            this.plControlM.Controls.Add(this.btnLuuM);
            this.plControlM.Controls.Add(this.btnXoaM);
            this.plControlM.Controls.Add(this.btnThemM);
            this.plControlM.Location = new System.Drawing.Point(794, 506);
            this.plControlM.Name = "plControlM";
            this.plControlM.Size = new System.Drawing.Size(190, 194);
            this.plControlM.TabIndex = 5;
            // 
            // btnSuaM
            // 
            this.btnSuaM.Location = new System.Drawing.Point(10, 57);
            this.btnSuaM.Name = "btnSuaM";
            this.btnSuaM.Size = new System.Drawing.Size(92, 39);
            this.btnSuaM.TabIndex = 4;
            this.btnSuaM.Text = "Sửa";
            this.btnSuaM.UseVisualStyleBackColor = true;
            this.btnSuaM.Click += new System.EventHandler(this.btnSuaM_Click);
            // 
            // btnTimM
            // 
            this.btnTimM.Location = new System.Drawing.Point(10, 147);
            this.btnTimM.Name = "btnTimM";
            this.btnTimM.Size = new System.Drawing.Size(170, 39);
            this.btnTimM.TabIndex = 3;
            this.btnTimM.Text = "Tìm kiếm";
            this.btnTimM.UseVisualStyleBackColor = true;
            this.btnTimM.Click += new System.EventHandler(this.btnTimM_Click);
            // 
            // btnLuuM
            // 
            this.btnLuuM.Location = new System.Drawing.Point(108, 12);
            this.btnLuuM.Name = "btnLuuM";
            this.btnLuuM.Size = new System.Drawing.Size(72, 129);
            this.btnLuuM.TabIndex = 2;
            this.btnLuuM.Text = "Lưu";
            this.btnLuuM.UseVisualStyleBackColor = true;
            this.btnLuuM.Click += new System.EventHandler(this.btnLuuM_Click);
            // 
            // btnXoaM
            // 
            this.btnXoaM.Location = new System.Drawing.Point(10, 102);
            this.btnXoaM.Name = "btnXoaM";
            this.btnXoaM.Size = new System.Drawing.Size(92, 39);
            this.btnXoaM.TabIndex = 1;
            this.btnXoaM.Text = "Xóa";
            this.btnXoaM.UseVisualStyleBackColor = true;
            this.btnXoaM.Click += new System.EventHandler(this.btnXoaM_Click);
            // 
            // btnThemM
            // 
            this.btnThemM.Location = new System.Drawing.Point(10, 12);
            this.btnThemM.Name = "btnThemM";
            this.btnThemM.Size = new System.Drawing.Size(92, 39);
            this.btnThemM.TabIndex = 0;
            this.btnThemM.Text = "Thêm";
            this.btnThemM.UseVisualStyleBackColor = true;
            this.btnThemM.Click += new System.EventHandler(this.btnThemM_Click);
            // 
            // plInfoM
            // 
            this.plInfoM.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.plInfoM.Controls.Add(this.txtsldb);
            this.plInfoM.Controls.Add(this.label16);
            this.plInfoM.Controls.Add(this.txtMaLoai);
            this.plInfoM.Controls.Add(this.label14);
            this.plInfoM.Controls.Add(this.txtGia);
            this.plInfoM.Controls.Add(this.label8);
            this.plInfoM.Controls.Add(this.txtTenMon);
            this.plInfoM.Controls.Add(this.label9);
            this.plInfoM.Controls.Add(this.txtMaMon);
            this.plInfoM.Controls.Add(this.label10);
            this.plInfoM.Location = new System.Drawing.Point(794, 6);
            this.plInfoM.Name = "plInfoM";
            this.plInfoM.Size = new System.Drawing.Size(392, 296);
            this.plInfoM.TabIndex = 4;
            // 
            // txtsldb
            // 
            this.txtsldb.Location = new System.Drawing.Point(254, 209);
            this.txtsldb.Name = "txtsldb";
            this.txtsldb.Size = new System.Drawing.Size(126, 34);
            this.txtsldb.TabIndex = 9;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(16, 212);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(185, 26);
            this.label16.TabIndex = 8;
            this.label16.Text = "Số lượng đã bán:";
            // 
            // txtMaLoai
            // 
            this.txtMaLoai.Location = new System.Drawing.Point(138, 61);
            this.txtMaLoai.Name = "txtMaLoai";
            this.txtMaLoai.Size = new System.Drawing.Size(242, 34);
            this.txtMaLoai.TabIndex = 7;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(16, 64);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 26);
            this.label14.TabIndex = 6;
            this.label14.Text = "Mã Loại:";
            // 
            // txtGia
            // 
            this.txtGia.Location = new System.Drawing.Point(138, 159);
            this.txtGia.Name = "txtGia";
            this.txtGia.Size = new System.Drawing.Size(242, 34);
            this.txtGia.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(57, 26);
            this.label8.TabIndex = 4;
            this.label8.Text = "Giá:";
            // 
            // txtTenMon
            // 
            this.txtTenMon.Location = new System.Drawing.Point(138, 109);
            this.txtTenMon.Name = "txtTenMon";
            this.txtTenMon.Size = new System.Drawing.Size(242, 34);
            this.txtTenMon.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(16, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(109, 26);
            this.label9.TabIndex = 2;
            this.label9.Text = "Tên món:";
            // 
            // txtMaMon
            // 
            this.txtMaMon.Location = new System.Drawing.Point(138, 14);
            this.txtMaMon.Name = "txtMaMon";
            this.txtMaMon.Size = new System.Drawing.Size(242, 34);
            this.txtMaMon.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(16, 17);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(105, 26);
            this.label10.TabIndex = 0;
            this.label10.Text = "Mã món:";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // QLNV
            // 
            this.QLNV.Controls.Add(this.plLuong);
            this.QLNV.Controls.Add(this.plQLNV);
            this.QLNV.Controls.Add(this.plSearch);
            this.QLNV.Controls.Add(this.plControl);
            this.QLNV.Controls.Add(this.plInfo);
            this.QLNV.Controls.Add(this.dgvNV);
            this.QLNV.Location = new System.Drawing.Point(4, 34);
            this.QLNV.Name = "QLNV";
            this.QLNV.Padding = new System.Windows.Forms.Padding(3);
            this.QLNV.Size = new System.Drawing.Size(1198, 805);
            this.QLNV.TabIndex = 0;
            this.QLNV.Text = "Quản lý Nhân viên";
            this.QLNV.UseVisualStyleBackColor = true;
            // 
            // plLuong
            // 
            this.plLuong.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.plLuong.Controls.Add(this.label28);
            this.plLuong.Controls.Add(this.txtMucLuong);
            this.plLuong.Controls.Add(this.trbMucLuong);
            this.plLuong.Controls.Add(this.label29);
            this.plLuong.Location = new System.Drawing.Point(739, 312);
            this.plLuong.Name = "plLuong";
            this.plLuong.Size = new System.Drawing.Size(450, 125);
            this.plLuong.TabIndex = 6;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(345, 72);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(62, 26);
            this.label28.TabIndex = 8;
            this.label28.Text = "đồng";
            // 
            // txtMucLuong
            // 
            this.txtMucLuong.Enabled = false;
            this.txtMucLuong.Location = new System.Drawing.Point(146, 69);
            this.txtMucLuong.Name = "txtMucLuong";
            this.txtMucLuong.Size = new System.Drawing.Size(199, 34);
            this.txtMucLuong.TabIndex = 7;
            // 
            // trbMucLuong
            // 
            this.trbMucLuong.Location = new System.Drawing.Point(146, 22);
            this.trbMucLuong.Maximum = 50;
            this.trbMucLuong.Name = "trbMucLuong";
            this.trbMucLuong.Size = new System.Drawing.Size(261, 56);
            this.trbMucLuong.TabIndex = 6;
            this.trbMucLuong.Scroll += new System.EventHandler(this.trbMucLuong_Scroll);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(13, 22);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(133, 26);
            this.label29.TabIndex = 5;
            this.label29.Text = "Mức lương:";
            // 
            // plQLNV
            // 
            this.plQLNV.BackColor = System.Drawing.SystemColors.Control;
            this.plQLNV.Controls.Add(this.txtAVGLuongCN);
            this.plQLNV.Controls.Add(this.label15);
            this.plQLNV.Controls.Add(this.txtTongLuongCN);
            this.plQLNV.Controls.Add(this.label23);
            this.plQLNV.Controls.Add(this.label25);
            this.plQLNV.Controls.Add(this.cbHien_NV_CN);
            this.plQLNV.Controls.Add(this.btnTim_NV_theoCN);
            this.plQLNV.Location = new System.Drawing.Point(739, 443);
            this.plQLNV.Name = "plQLNV";
            this.plQLNV.Size = new System.Drawing.Size(448, 156);
            this.plQLNV.TabIndex = 5;
            // 
            // txtAVGLuongCN
            // 
            this.txtAVGLuongCN.Location = new System.Drawing.Point(210, 116);
            this.txtAVGLuongCN.Name = "txtAVGLuongCN";
            this.txtAVGLuongCN.Size = new System.Drawing.Size(235, 34);
            this.txtAVGLuongCN.TabIndex = 19;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(12, 119);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(165, 26);
            this.label15.TabIndex = 18;
            this.label15.Text = "Lương TB CN:";
            // 
            // txtTongLuongCN
            // 
            this.txtTongLuongCN.Location = new System.Drawing.Point(210, 68);
            this.txtTongLuongCN.Name = "txtTongLuongCN";
            this.txtTongLuongCN.Size = new System.Drawing.Size(235, 34);
            this.txtTongLuongCN.TabIndex = 17;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(8, 71);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(177, 26);
            this.label23.TabIndex = 16;
            this.label23.Text = "Tổng lương CN:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(8, 18);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(95, 26);
            this.label25.TabIndex = 15;
            this.label25.Text = "MaCN :";
            // 
            // cbHien_NV_CN
            // 
            this.cbHien_NV_CN.FormattingEnabled = true;
            this.cbHien_NV_CN.Items.AddRange(new object[] {
            "101",
            "102",
            "103",
            "104",
            "105"});
            this.cbHien_NV_CN.Location = new System.Drawing.Point(120, 14);
            this.cbHien_NV_CN.Name = "cbHien_NV_CN";
            this.cbHien_NV_CN.Size = new System.Drawing.Size(83, 33);
            this.cbHien_NV_CN.TabIndex = 6;
            // 
            // btnTim_NV_theoCN
            // 
            this.btnTim_NV_theoCN.Font = new System.Drawing.Font("Times New Roman", 13F, System.Drawing.FontStyle.Bold);
            this.btnTim_NV_theoCN.Location = new System.Drawing.Point(210, 14);
            this.btnTim_NV_theoCN.Name = "btnTim_NV_theoCN";
            this.btnTim_NV_theoCN.Size = new System.Drawing.Size(235, 33);
            this.btnTim_NV_theoCN.TabIndex = 5;
            this.btnTim_NV_theoCN.Text = "Hiện";
            this.btnTim_NV_theoCN.UseVisualStyleBackColor = true;
            this.btnTim_NV_theoCN.Click += new System.EventHandler(this.btnTim_NV_theoCN_Click);
            // 
            // plSearch
            // 
            this.plSearch.BackColor = System.Drawing.SystemColors.Control;
            this.plSearch.Controls.Add(this.radioButton1);
            this.plSearch.Controls.Add(this.pbReload);
            this.plSearch.Controls.Add(this.radSDT);
            this.plSearch.Controls.Add(this.radDiaChi);
            this.plSearch.Controls.Add(this.radChucVu);
            this.plSearch.Controls.Add(this.radHoTen);
            this.plSearch.Controls.Add(this.btnSearch);
            this.plSearch.Location = new System.Drawing.Point(975, 605);
            this.plSearch.Name = "plSearch";
            this.plSearch.Size = new System.Drawing.Size(212, 194);
            this.plSearch.TabIndex = 3;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButton1.Location = new System.Drawing.Point(14, 118);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(78, 23);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "Lương";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // pbReload
            // 
            this.pbReload.Image = global::_ADO.NET_QuanLy_QuanTraSua_Demo.Properties.Resources.Reload;
            this.pbReload.Location = new System.Drawing.Point(142, 12);
            this.pbReload.Name = "pbReload";
            this.pbReload.Size = new System.Drawing.Size(42, 39);
            this.pbReload.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReload.TabIndex = 10;
            this.pbReload.TabStop = false;
            this.pbReload.Click += new System.EventHandler(this.pbReload_Click);
            // 
            // radSDT
            // 
            this.radSDT.AutoSize = true;
            this.radSDT.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radSDT.Location = new System.Drawing.Point(14, 96);
            this.radSDT.Name = "radSDT";
            this.radSDT.Size = new System.Drawing.Size(61, 23);
            this.radSDT.TabIndex = 9;
            this.radSDT.TabStop = true;
            this.radSDT.Text = "SĐT";
            this.radSDT.UseVisualStyleBackColor = true;
            this.radSDT.CheckedChanged += new System.EventHandler(this.radSDT_CheckedChanged);
            // 
            // radDiaChi
            // 
            this.radDiaChi.AutoSize = true;
            this.radDiaChi.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radDiaChi.Location = new System.Drawing.Point(14, 67);
            this.radDiaChi.Name = "radDiaChi";
            this.radDiaChi.Size = new System.Drawing.Size(83, 23);
            this.radDiaChi.TabIndex = 8;
            this.radDiaChi.TabStop = true;
            this.radDiaChi.Text = "Địa chỉ";
            this.radDiaChi.UseVisualStyleBackColor = true;
            this.radDiaChi.CheckedChanged += new System.EventHandler(this.radDiaChi_CheckedChanged);
            // 
            // radChucVu
            // 
            this.radChucVu.AutoSize = true;
            this.radChucVu.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radChucVu.Location = new System.Drawing.Point(14, 38);
            this.radChucVu.Name = "radChucVu";
            this.radChucVu.Size = new System.Drawing.Size(90, 23);
            this.radChucVu.TabIndex = 7;
            this.radChucVu.TabStop = true;
            this.radChucVu.Text = "Chức vụ";
            this.radChucVu.UseVisualStyleBackColor = true;
            this.radChucVu.CheckedChanged += new System.EventHandler(this.radChucVu_CheckedChanged);
            // 
            // radHoTen
            // 
            this.radHoTen.AutoSize = true;
            this.radHoTen.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radHoTen.Location = new System.Drawing.Point(14, 12);
            this.radHoTen.Name = "radHoTen";
            this.radHoTen.Size = new System.Drawing.Size(84, 23);
            this.radHoTen.TabIndex = 6;
            this.radHoTen.TabStop = true;
            this.radHoTen.Text = "Tên NV";
            this.radHoTen.UseVisualStyleBackColor = true;
            this.radHoTen.CheckedChanged += new System.EventHandler(this.radHoTen_CheckedChanged);
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(14, 147);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(170, 39);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.Text = "Tìm kiếm";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // plControl
            // 
            this.plControl.BackColor = System.Drawing.SystemColors.Control;
            this.plControl.Controls.Add(this.btnSua);
            this.plControl.Controls.Add(this.btnTim);
            this.plControl.Controls.Add(this.btnLuu);
            this.plControl.Controls.Add(this.btnXoa);
            this.plControl.Controls.Add(this.btnThem);
            this.plControl.Location = new System.Drawing.Point(739, 605);
            this.plControl.Name = "plControl";
            this.plControl.Size = new System.Drawing.Size(230, 194);
            this.plControl.TabIndex = 2;
            // 
            // btnSua
            // 
            this.btnSua.Location = new System.Drawing.Point(31, 57);
            this.btnSua.Name = "btnSua";
            this.btnSua.Size = new System.Drawing.Size(92, 39);
            this.btnSua.TabIndex = 4;
            this.btnSua.Text = "Sửa";
            this.btnSua.UseVisualStyleBackColor = true;
            this.btnSua.Click += new System.EventHandler(this.btnSua_Click);
            // 
            // btnTim
            // 
            this.btnTim.Location = new System.Drawing.Point(31, 147);
            this.btnTim.Name = "btnTim";
            this.btnTim.Size = new System.Drawing.Size(170, 39);
            this.btnTim.TabIndex = 3;
            this.btnTim.Text = "Tìm kiếm";
            this.btnTim.UseVisualStyleBackColor = true;
            this.btnTim.Click += new System.EventHandler(this.btnTim_Click);
            // 
            // btnLuu
            // 
            this.btnLuu.Location = new System.Drawing.Point(129, 12);
            this.btnLuu.Name = "btnLuu";
            this.btnLuu.Size = new System.Drawing.Size(72, 129);
            this.btnLuu.TabIndex = 2;
            this.btnLuu.Text = "Lưu";
            this.btnLuu.UseVisualStyleBackColor = true;
            this.btnLuu.Click += new System.EventHandler(this.btnLuu_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Location = new System.Drawing.Point(31, 102);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(92, 39);
            this.btnXoa.TabIndex = 1;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // btnThem
            // 
            this.btnThem.Location = new System.Drawing.Point(31, 12);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(92, 39);
            this.btnThem.TabIndex = 0;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // plInfo
            // 
            this.plInfo.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.plInfo.Controls.Add(this.txtMaCN);
            this.plInfo.Controls.Add(this.label13);
            this.plInfo.Controls.Add(this.txtTuoi);
            this.plInfo.Controls.Add(this.label12);
            this.plInfo.Controls.Add(this.txtEmail);
            this.plInfo.Controls.Add(this.label11);
            this.plInfo.Controls.Add(this.txtLuong);
            this.plInfo.Controls.Add(this.label5);
            this.plInfo.Controls.Add(this.txtSDT);
            this.plInfo.Controls.Add(this.label4);
            this.plInfo.Controls.Add(this.txtDiaChi);
            this.plInfo.Controls.Add(this.label3);
            this.plInfo.Controls.Add(this.txtChucVu);
            this.plInfo.Controls.Add(this.label2);
            this.plInfo.Controls.Add(this.txtHoTen);
            this.plInfo.Controls.Add(this.label1);
            this.plInfo.Location = new System.Drawing.Point(740, 7);
            this.plInfo.Name = "plInfo";
            this.plInfo.Size = new System.Drawing.Size(450, 297);
            this.plInfo.TabIndex = 1;
            // 
            // txtMaCN
            // 
            this.txtMaCN.Location = new System.Drawing.Point(119, 255);
            this.txtMaCN.Name = "txtMaCN";
            this.txtMaCN.Size = new System.Drawing.Size(57, 34);
            this.txtMaCN.TabIndex = 15;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 255);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 26);
            this.label13.TabIndex = 14;
            this.label13.Text = "MaCN";
            // 
            // txtTuoi
            // 
            this.txtTuoi.Location = new System.Drawing.Point(119, 112);
            this.txtTuoi.Name = "txtTuoi";
            this.txtTuoi.Size = new System.Drawing.Size(40, 34);
            this.txtTuoi.TabIndex = 13;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(65, 26);
            this.label12.TabIndex = 12;
            this.label12.Text = "Tuổi:";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(119, 61);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(328, 34);
            this.txtEmail.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 61);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(81, 26);
            this.label11.TabIndex = 10;
            this.label11.Text = "Email:";
            // 
            // txtLuong
            // 
            this.txtLuong.Location = new System.Drawing.Point(266, 252);
            this.txtLuong.Name = "txtLuong";
            this.txtLuong.Size = new System.Drawing.Size(181, 34);
            this.txtLuong.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(182, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 26);
            this.label5.TabIndex = 8;
            this.label5.Text = "Lương:";
            // 
            // txtSDT
            // 
            this.txtSDT.Location = new System.Drawing.Point(119, 209);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(328, 34);
            this.txtSDT.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 212);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 26);
            this.label4.TabIndex = 6;
            this.label4.Text = "SĐT:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(119, 157);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(328, 34);
            this.txtDiaChi.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "Địa chỉ:";
            // 
            // txtChucVu
            // 
            this.txtChucVu.Location = new System.Drawing.Point(266, 112);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(181, 34);
            this.txtChucVu.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(165, 112);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "Chức vụ:";
            // 
            // txtHoTen
            // 
            this.txtHoTen.Location = new System.Drawing.Point(119, 14);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(328, 34);
            this.txtHoTen.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên NV:";
            // 
            // dgvNV
            // 
            this.dgvNV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNV.Location = new System.Drawing.Point(7, 7);
            this.dgvNV.Name = "dgvNV";
            this.dgvNV.RowHeadersWidth = 51;
            this.dgvNV.RowTemplate.Height = 24;
            this.dgvNV.Size = new System.Drawing.Size(726, 792);
            this.dgvNV.TabIndex = 0;
            this.dgvNV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNV_CellClick);
            this.dgvNV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNV_CellContentClick);
            // 
            // tabManager
            // 
            this.tabManager.Controls.Add(this.QLNV);
            this.tabManager.Controls.Add(this.QLMENU);
            this.tabManager.Controls.Add(this.tabPage1);
            this.tabManager.Controls.Add(this.tabPage2);
            this.tabManager.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabManager.Location = new System.Drawing.Point(12, 12);
            this.tabManager.Name = "tabManager";
            this.tabManager.SelectedIndex = 0;
            this.tabManager.Size = new System.Drawing.Size(1206, 843);
            this.tabManager.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Controls.Add(this.plscroll_KH);
            this.tabPage1.Controls.Add(this.plSearchK);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Controls.Add(this.plInfoK);
            this.tabPage1.Controls.Add(this.dgvKH);
            this.tabPage1.Location = new System.Drawing.Point(4, 34);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1198, 805);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "Quản lý Khách hàng";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.Control;
            this.panel3.Controls.Add(this.top5kh);
            this.panel3.Location = new System.Drawing.Point(738, 370);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(452, 86);
            this.panel3.TabIndex = 10;
            // 
            // top5kh
            // 
            this.top5kh.Location = new System.Drawing.Point(10, 16);
            this.top5kh.Name = "top5kh";
            this.top5kh.Size = new System.Drawing.Size(439, 54);
            this.top5kh.TabIndex = 6;
            this.top5kh.Text = "Top 5 khách hàng mua nhiều nhất";
            this.top5kh.UseVisualStyleBackColor = true;
            this.top5kh.Click += new System.EventHandler(this.top5kh_Click);
            // 
            // plscroll_KH
            // 
            this.plscroll_KH.BackColor = System.Drawing.SystemColors.Control;
            this.plscroll_KH.Controls.Add(this.label26);
            this.plscroll_KH.Controls.Add(this.txtMucChiTieu);
            this.plscroll_KH.Controls.Add(this.trbMucChiTieu);
            this.plscroll_KH.Controls.Add(this.label27);
            this.plscroll_KH.Location = new System.Drawing.Point(738, 462);
            this.plscroll_KH.Name = "plscroll_KH";
            this.plscroll_KH.Size = new System.Drawing.Size(454, 100);
            this.plscroll_KH.TabIndex = 9;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(366, 66);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(62, 26);
            this.label26.TabIndex = 4;
            this.label26.Text = "đồng";
            // 
            // txtMucChiTieu
            // 
            this.txtMucChiTieu.Enabled = false;
            this.txtMucChiTieu.Location = new System.Drawing.Point(167, 64);
            this.txtMucChiTieu.Name = "txtMucChiTieu";
            this.txtMucChiTieu.Size = new System.Drawing.Size(193, 34);
            this.txtMucChiTieu.TabIndex = 3;
            // 
            // trbMucChiTieu
            // 
            this.trbMucChiTieu.Location = new System.Drawing.Point(167, 16);
            this.trbMucChiTieu.Maximum = 50;
            this.trbMucChiTieu.Name = "trbMucChiTieu";
            this.trbMucChiTieu.Size = new System.Drawing.Size(261, 56);
            this.trbMucChiTieu.TabIndex = 2;
            this.trbMucChiTieu.Scroll += new System.EventHandler(this.trbMucChiTieu_Scroll);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(16, 16);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(150, 26);
            this.label27.TabIndex = 0;
            this.label27.Text = "Mức chi tiêu:";
            // 
            // plSearchK
            // 
            this.plSearchK.BackColor = System.Drawing.SystemColors.Control;
            this.plSearchK.Controls.Add(this.radTongCT);
            this.plSearchK.Controls.Add(this.pbReloadKH);
            this.plSearchK.Controls.Add(this.radSDT_KH);
            this.plSearchK.Controls.Add(this.radDiaChiKH);
            this.plSearchK.Controls.Add(this.radCapBac);
            this.plSearchK.Controls.Add(this.radTenKH);
            this.plSearchK.Controls.Add(this.btnSearchK);
            this.plSearchK.Location = new System.Drawing.Point(981, 566);
            this.plSearchK.Name = "plSearchK";
            this.plSearchK.Size = new System.Drawing.Size(211, 194);
            this.plSearchK.TabIndex = 6;
            // 
            // radTongCT
            // 
            this.radTongCT.AutoSize = true;
            this.radTongCT.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTongCT.Location = new System.Drawing.Point(14, 118);
            this.radTongCT.Name = "radTongCT";
            this.radTongCT.Size = new System.Drawing.Size(93, 23);
            this.radTongCT.TabIndex = 11;
            this.radTongCT.TabStop = true;
            this.radTongCT.Text = "Tổng CT";
            this.radTongCT.UseVisualStyleBackColor = true;
            this.radTongCT.CheckedChanged += new System.EventHandler(this.radTongCT_CheckedChanged);
            // 
            // pbReloadKH
            // 
            this.pbReloadKH.Image = global::_ADO.NET_QuanLy_QuanTraSua_Demo.Properties.Resources.Reload;
            this.pbReloadKH.Location = new System.Drawing.Point(142, 12);
            this.pbReloadKH.Name = "pbReloadKH";
            this.pbReloadKH.Size = new System.Drawing.Size(42, 39);
            this.pbReloadKH.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbReloadKH.TabIndex = 10;
            this.pbReloadKH.TabStop = false;
            this.pbReloadKH.Click += new System.EventHandler(this.pbReloadKH_Click);
            // 
            // radSDT_KH
            // 
            this.radSDT_KH.AutoSize = true;
            this.radSDT_KH.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radSDT_KH.Location = new System.Drawing.Point(14, 96);
            this.radSDT_KH.Name = "radSDT_KH";
            this.radSDT_KH.Size = new System.Drawing.Size(61, 23);
            this.radSDT_KH.TabIndex = 9;
            this.radSDT_KH.TabStop = true;
            this.radSDT_KH.Text = "SĐT";
            this.radSDT_KH.UseVisualStyleBackColor = true;
            this.radSDT_KH.CheckedChanged += new System.EventHandler(this.radSDT_KH_CheckedChanged);
            // 
            // radDiaChiKH
            // 
            this.radDiaChiKH.AutoSize = true;
            this.radDiaChiKH.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radDiaChiKH.Location = new System.Drawing.Point(14, 67);
            this.radDiaChiKH.Name = "radDiaChiKH";
            this.radDiaChiKH.Size = new System.Drawing.Size(83, 23);
            this.radDiaChiKH.TabIndex = 8;
            this.radDiaChiKH.TabStop = true;
            this.radDiaChiKH.Text = "Địa chỉ";
            this.radDiaChiKH.UseVisualStyleBackColor = true;
            this.radDiaChiKH.CheckedChanged += new System.EventHandler(this.radDiaChiKH_CheckedChanged);
            // 
            // radCapBac
            // 
            this.radCapBac.AutoSize = true;
            this.radCapBac.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radCapBac.Location = new System.Drawing.Point(14, 38);
            this.radCapBac.Name = "radCapBac";
            this.radCapBac.Size = new System.Drawing.Size(88, 23);
            this.radCapBac.TabIndex = 7;
            this.radCapBac.TabStop = true;
            this.radCapBac.Text = "Cấp bậc";
            this.radCapBac.UseVisualStyleBackColor = true;
            this.radCapBac.CheckedChanged += new System.EventHandler(this.radCapBac_CheckedChanged);
            // 
            // radTenKH
            // 
            this.radTenKH.AutoSize = true;
            this.radTenKH.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radTenKH.Location = new System.Drawing.Point(14, 12);
            this.radTenKH.Name = "radTenKH";
            this.radTenKH.Size = new System.Drawing.Size(86, 23);
            this.radTenKH.TabIndex = 6;
            this.radTenKH.TabStop = true;
            this.radTenKH.Text = "Tên KH";
            this.radTenKH.UseVisualStyleBackColor = true;
            this.radTenKH.CheckedChanged += new System.EventHandler(this.radTenKH_CheckedChanged);
            // 
            // btnSearchK
            // 
            this.btnSearchK.Location = new System.Drawing.Point(14, 147);
            this.btnSearchK.Name = "btnSearchK";
            this.btnSearchK.Size = new System.Drawing.Size(170, 39);
            this.btnSearchK.TabIndex = 5;
            this.btnSearchK.Text = "Tìm kiếm";
            this.btnSearchK.UseVisualStyleBackColor = true;
            this.btnSearchK.Click += new System.EventHandler(this.btnSearchK_Click_1);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.btnSuaK);
            this.panel2.Controls.Add(this.btnTimKiemK);
            this.panel2.Controls.Add(this.btnLuuK);
            this.panel2.Controls.Add(this.btnXoaK);
            this.panel2.Controls.Add(this.btnThemK);
            this.panel2.Location = new System.Drawing.Point(738, 565);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(237, 194);
            this.panel2.TabIndex = 5;
            // 
            // btnSuaK
            // 
            this.btnSuaK.Location = new System.Drawing.Point(33, 57);
            this.btnSuaK.Name = "btnSuaK";
            this.btnSuaK.Size = new System.Drawing.Size(92, 39);
            this.btnSuaK.TabIndex = 4;
            this.btnSuaK.Text = "Sửa";
            this.btnSuaK.UseVisualStyleBackColor = true;
            this.btnSuaK.Click += new System.EventHandler(this.btnSuaK_Click);
            // 
            // btnTimKiemK
            // 
            this.btnTimKiemK.Location = new System.Drawing.Point(33, 147);
            this.btnTimKiemK.Name = "btnTimKiemK";
            this.btnTimKiemK.Size = new System.Drawing.Size(170, 39);
            this.btnTimKiemK.TabIndex = 3;
            this.btnTimKiemK.Text = "Tìm kiếm";
            this.btnTimKiemK.UseVisualStyleBackColor = true;
            this.btnTimKiemK.Click += new System.EventHandler(this.btnTimKiemK_Click);
            // 
            // btnLuuK
            // 
            this.btnLuuK.Location = new System.Drawing.Point(131, 12);
            this.btnLuuK.Name = "btnLuuK";
            this.btnLuuK.Size = new System.Drawing.Size(72, 129);
            this.btnLuuK.TabIndex = 2;
            this.btnLuuK.Text = "Lưu";
            this.btnLuuK.UseVisualStyleBackColor = true;
            this.btnLuuK.Click += new System.EventHandler(this.btnLuuK_Click);
            // 
            // btnXoaK
            // 
            this.btnXoaK.Location = new System.Drawing.Point(33, 102);
            this.btnXoaK.Name = "btnXoaK";
            this.btnXoaK.Size = new System.Drawing.Size(92, 39);
            this.btnXoaK.TabIndex = 1;
            this.btnXoaK.Text = "Xóa";
            this.btnXoaK.UseVisualStyleBackColor = true;
            this.btnXoaK.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnThemK
            // 
            this.btnThemK.Location = new System.Drawing.Point(33, 12);
            this.btnThemK.Name = "btnThemK";
            this.btnThemK.Size = new System.Drawing.Size(92, 39);
            this.btnThemK.TabIndex = 0;
            this.btnThemK.Text = "Thêm";
            this.btnThemK.UseVisualStyleBackColor = true;
            this.btnThemK.Click += new System.EventHandler(this.btnThemK_Click);
            // 
            // plInfoK
            // 
            this.plInfoK.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.plInfoK.Controls.Add(this.txtEmailKH);
            this.plInfoK.Controls.Add(this.txtCapBac);
            this.plInfoK.Controls.Add(this.label17);
            this.plInfoK.Controls.Add(this.txtTuoiKH);
            this.plInfoK.Controls.Add(this.label18);
            this.plInfoK.Controls.Add(this.label19);
            this.plInfoK.Controls.Add(this.label20);
            this.plInfoK.Controls.Add(this.txtChiTieu);
            this.plInfoK.Controls.Add(this.label21);
            this.plInfoK.Controls.Add(this.txtDiaChiKH);
            this.plInfoK.Controls.Add(this.label22);
            this.plInfoK.Controls.Add(this.txtSDTKH);
            this.plInfoK.Controls.Add(this.txtTenKH);
            this.plInfoK.Controls.Add(this.label24);
            this.plInfoK.Location = new System.Drawing.Point(738, 7);
            this.plInfoK.Name = "plInfoK";
            this.plInfoK.Size = new System.Drawing.Size(452, 357);
            this.plInfoK.TabIndex = 4;
            // 
            // txtEmailKH
            // 
            this.txtEmailKH.Location = new System.Drawing.Point(119, 58);
            this.txtEmailKH.Name = "txtEmailKH";
            this.txtEmailKH.Size = new System.Drawing.Size(330, 34);
            this.txtEmailKH.TabIndex = 16;
            // 
            // txtCapBac
            // 
            this.txtCapBac.Location = new System.Drawing.Point(119, 310);
            this.txtCapBac.Name = "txtCapBac";
            this.txtCapBac.Size = new System.Drawing.Size(330, 34);
            this.txtCapBac.TabIndex = 15;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 310);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(104, 26);
            this.label17.TabIndex = 14;
            this.label17.Text = "Cấp bậc:";
            // 
            // txtTuoiKH
            // 
            this.txtTuoiKH.Location = new System.Drawing.Point(119, 112);
            this.txtTuoiKH.Name = "txtTuoiKH";
            this.txtTuoiKH.Size = new System.Drawing.Size(330, 34);
            this.txtTuoiKH.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(12, 112);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(65, 26);
            this.label18.TabIndex = 12;
            this.label18.Text = "Tuổi:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 61);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(81, 26);
            this.label19.TabIndex = 10;
            this.label19.Text = "Email:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(12, 267);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(102, 26);
            this.label20.TabIndex = 8;
            this.label20.Text = "Chi tiêu:";
            // 
            // txtChiTieu
            // 
            this.txtChiTieu.Location = new System.Drawing.Point(119, 264);
            this.txtChiTieu.Name = "txtChiTieu";
            this.txtChiTieu.Size = new System.Drawing.Size(330, 34);
            this.txtChiTieu.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(12, 165);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(63, 26);
            this.label21.TabIndex = 6;
            this.label21.Text = "SĐT:";
            // 
            // txtDiaChiKH
            // 
            this.txtDiaChiKH.Location = new System.Drawing.Point(119, 212);
            this.txtDiaChiKH.Name = "txtDiaChiKH";
            this.txtDiaChiKH.Size = new System.Drawing.Size(330, 34);
            this.txtDiaChiKH.TabIndex = 5;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(12, 215);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(93, 26);
            this.label22.TabIndex = 4;
            this.label22.Text = "Địa chỉ:";
            // 
            // txtSDTKH
            // 
            this.txtSDTKH.Location = new System.Drawing.Point(119, 162);
            this.txtSDTKH.Name = "txtSDTKH";
            this.txtSDTKH.Size = new System.Drawing.Size(330, 34);
            this.txtSDTKH.TabIndex = 3;
            // 
            // txtTenKH
            // 
            this.txtTenKH.Location = new System.Drawing.Point(119, 14);
            this.txtTenKH.Name = "txtTenKH";
            this.txtTenKH.Size = new System.Drawing.Size(330, 34);
            this.txtTenKH.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 14);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(103, 26);
            this.label24.TabIndex = 0;
            this.label24.Text = "Tên KH:";
            // 
            // dgvKH
            // 
            this.dgvKH.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKH.Location = new System.Drawing.Point(6, 7);
            this.dgvKH.Name = "dgvKH";
            this.dgvKH.RowHeadersWidth = 51;
            this.dgvKH.RowTemplate.Height = 24;
            this.dgvKH.Size = new System.Drawing.Size(726, 753);
            this.dgvKH.TabIndex = 1;
            this.dgvKH.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKH_CellClick);
            this.dgvKH.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvKH_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgvHD);
            this.tabPage2.Controls.Add(this.plQLHD);
            this.tabPage2.Controls.Add(this.plQLtKQL);
            this.tabPage2.Location = new System.Drawing.Point(4, 34);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1198, 805);
            this.tabPage2.TabIndex = 3;
            this.tabPage2.Text = "Quản lý tài khoản";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // plQLtKQL
            // 
            this.plQLtKQL.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.plQLtKQL.Controls.Add(this.label31);
            this.plQLtKQL.Controls.Add(this.label30);
            this.plQLtKQL.Controls.Add(this.blTenTK_NQL);
            this.plQLtKQL.Controls.Add(this.lbMaNQL);
            this.plQLtKQL.Controls.Add(this.btnXoaNguoiQuanLy);
            this.plQLtKQL.Location = new System.Drawing.Point(739, 11);
            this.plQLtKQL.Name = "plQLtKQL";
            this.plQLtKQL.Size = new System.Drawing.Size(452, 200);
            this.plQLtKQL.TabIndex = 19;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(30, 74);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(129, 26);
            this.label31.TabIndex = 18;
            this.label31.Text = "Tài khoản :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(30, 31);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(124, 26);
            this.label30.TabIndex = 17;
            this.label30.Text = "Mã NQL  :";
            // 
            // blTenTK_NQL
            // 
            this.blTenTK_NQL.AutoSize = true;
            this.blTenTK_NQL.Location = new System.Drawing.Point(182, 74);
            this.blTenTK_NQL.Name = "blTenTK_NQL";
            this.blTenTK_NQL.Size = new System.Drawing.Size(160, 26);
            this.blTenTK_NQL.TabIndex = 16;
            this.blTenTK_NQL.Text = "Tên Tài khoản";
            // 
            // lbMaNQL
            // 
            this.lbMaNQL.AutoSize = true;
            this.lbMaNQL.Location = new System.Drawing.Point(182, 31);
            this.lbMaNQL.Name = "lbMaNQL";
            this.lbMaNQL.Size = new System.Drawing.Size(105, 26);
            this.lbMaNQL.TabIndex = 15;
            this.lbMaNQL.Text = "Mã NQL";
            // 
            // btnXoaNguoiQuanLy
            // 
            this.btnXoaNguoiQuanLy.Location = new System.Drawing.Point(30, 131);
            this.btnXoaNguoiQuanLy.Name = "btnXoaNguoiQuanLy";
            this.btnXoaNguoiQuanLy.Size = new System.Drawing.Size(392, 39);
            this.btnXoaNguoiQuanLy.TabIndex = 14;
            this.btnXoaNguoiQuanLy.Text = "Xóa người quản lý hiện tại";
            this.btnXoaNguoiQuanLy.UseVisualStyleBackColor = true;
            this.btnXoaNguoiQuanLy.Click += new System.EventHandler(this.btnXoaNguoiQuanLy_Click_1);
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(168, 76);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(160, 26);
            this.label34.TabIndex = 16;
            this.label34.Text = "Tên Tài khoản";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(168, 33);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(105, 26);
            this.label35.TabIndex = 15;
            this.label35.Text = "Mã NQL";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(16, 133);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(392, 39);
            this.button1.TabIndex = 14;
            this.button1.Text = "Xóa người quản lý hiện tại";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(16, 76);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(129, 26);
            this.label32.TabIndex = 18;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(16, 33);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(124, 26);
            this.label33.TabIndex = 17;
            // 
            // dgvHD
            // 
            this.dgvHD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHD.Location = new System.Drawing.Point(7, 217);
            this.dgvHD.Name = "dgvHD";
            this.dgvHD.RowHeadersWidth = 51;
            this.dgvHD.RowTemplate.Height = 24;
            this.dgvHD.Size = new System.Drawing.Size(1184, 576);
            this.dgvHD.TabIndex = 23;
            // 
            // plQLHD
            // 
            this.plQLHD.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.plQLHD.Controls.Add(this.label37);
            this.plQLHD.Controls.Add(this.btnHD);
            this.plQLHD.Location = new System.Drawing.Point(7, 11);
            this.plQLHD.Name = "plQLHD";
            this.plQLHD.Size = new System.Drawing.Size(726, 200);
            this.plQLHD.TabIndex = 22;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(295, 49);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(104, 26);
            this.label37.TabIndex = 17;
            this.label37.Text = "Hóa Đơn";
            // 
            // btnHD
            // 
            this.btnHD.Location = new System.Drawing.Point(32, 131);
            this.btnHD.Name = "btnHD";
            this.btnHD.Size = new System.Drawing.Size(663, 39);
            this.btnHD.TabIndex = 14;
            this.btnHD.Text = "Hiện hóa đơn theo View";
            this.btnHD.UseVisualStyleBackColor = true;
            this.btnHD.Click += new System.EventHandler(this.btnHD_Click);
            // 
            // Form_Management
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1218, 846);
            this.Controls.Add(this.tabManager);
            this.Name = "Form_Management";
            this.Text = "Quản Lý";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form_Management_FormClosed);
            this.Load += new System.EventHandler(this.Form_Management_Load);
            this.QLMENU.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.plMucGia.ResumeLayout(false);
            this.plMucGia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbMucGia)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMenu)).EndInit();
            this.plSearchM.ResumeLayout(false);
            this.plSearchM.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReloadM)).EndInit();
            this.plControlM.ResumeLayout(false);
            this.plInfoM.ResumeLayout(false);
            this.plInfoM.PerformLayout();
            this.QLNV.ResumeLayout(false);
            this.plLuong.ResumeLayout(false);
            this.plLuong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbMucLuong)).EndInit();
            this.plQLNV.ResumeLayout(false);
            this.plQLNV.PerformLayout();
            this.plSearch.ResumeLayout(false);
            this.plSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReload)).EndInit();
            this.plControl.ResumeLayout(false);
            this.plInfo.ResumeLayout(false);
            this.plInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).EndInit();
            this.tabManager.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.plscroll_KH.ResumeLayout(false);
            this.plscroll_KH.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trbMucChiTieu)).EndInit();
            this.plSearchK.ResumeLayout(false);
            this.plSearchK.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbReloadKH)).EndInit();
            this.panel2.ResumeLayout(false);
            this.plInfoK.ResumeLayout(false);
            this.plInfoK.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKH)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.plQLtKQL.ResumeLayout(false);
            this.plQLtKQL.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHD)).EndInit();
            this.plQLHD.ResumeLayout(false);
            this.plQLHD.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage QLMENU;
        private System.Windows.Forms.Panel plMucGia;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtMucGia;
        private System.Windows.Forms.TrackBar trbMucGia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dgvMenu;
        private System.Windows.Forms.Panel plSearchM;
        private System.Windows.Forms.PictureBox pbReloadM;
        private System.Windows.Forms.RadioButton radGia;
        private System.Windows.Forms.RadioButton radTenMon;
        private System.Windows.Forms.RadioButton radMaMon;
        private System.Windows.Forms.Button btnSearchM;
        private System.Windows.Forms.Panel plControlM;
        private System.Windows.Forms.Button btnSuaM;
        private System.Windows.Forms.Button btnTimM;
        private System.Windows.Forms.Button btnLuuM;
        private System.Windows.Forms.Button btnXoaM;
        private System.Windows.Forms.Button btnThemM;
        private System.Windows.Forms.Panel plInfoM;
        private System.Windows.Forms.TextBox txtGia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtTenMon;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtMaMon;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TabPage QLNV;
        private System.Windows.Forms.Panel plSearch;
        private System.Windows.Forms.PictureBox pbReload;
        private System.Windows.Forms.RadioButton radSDT;
        private System.Windows.Forms.RadioButton radDiaChi;
        private System.Windows.Forms.RadioButton radChucVu;
        private System.Windows.Forms.RadioButton radHoTen;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Panel plControl;
        private System.Windows.Forms.Button btnSua;
        private System.Windows.Forms.Button btnTim;
        private System.Windows.Forms.Button btnLuu;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Panel plInfo;
        private System.Windows.Forms.TextBox txtLuong;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvNV;
        private System.Windows.Forms.TabControl tabManager;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtMaCN;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTuoi;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtsldb;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtMaLoai;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dgvKH;
        private System.Windows.Forms.Panel plSearchK;
        private System.Windows.Forms.PictureBox pbReloadKH;
        private System.Windows.Forms.RadioButton radSDT_KH;
        private System.Windows.Forms.RadioButton radDiaChiKH;
        private System.Windows.Forms.RadioButton radCapBac;
        private System.Windows.Forms.RadioButton radTenKH;
        private System.Windows.Forms.Button btnSearchK;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSuaK;
        private System.Windows.Forms.Button btnTimKiemK;
        private System.Windows.Forms.Button btnLuuK;
        private System.Windows.Forms.Button btnXoaK;
        private System.Windows.Forms.Button btnThemK;
        private System.Windows.Forms.Panel plInfoK;
        private System.Windows.Forms.TextBox txtCapBac;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtTuoiKH;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtChiTieu;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtDiaChiKH;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtSDTKH;
        private System.Windows.Forms.TextBox txtTenKH;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtEmailKH;
        private System.Windows.Forms.Panel plQLNV;
        private System.Windows.Forms.TextBox txtAVGLuongCN;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtTongLuongCN;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cbHien_NV_CN;
        private System.Windows.Forms.Button btnTim_NV_theoCN;
        private System.Windows.Forms.Panel plscroll_KH;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txtMucChiTieu;
        private System.Windows.Forms.TrackBar trbMucChiTieu;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel plLuong;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtMucLuong;
        private System.Windows.Forms.TrackBar trbMucLuong;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radTongCT;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel plQLtKQL;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Button btnXoaNguoiQuanLy;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label blTenTK_NQL;
        private System.Windows.Forms.Label lbMaNQL;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button top5mon;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button top5kh;
        private System.Windows.Forms.DataGridView dgvHD;
        private System.Windows.Forms.Panel plQLHD;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button btnHD;
    }
}