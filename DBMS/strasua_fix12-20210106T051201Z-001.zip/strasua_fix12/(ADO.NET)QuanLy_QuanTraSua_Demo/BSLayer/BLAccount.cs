﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _ADO.NET_QuanLy_QuanTraSua_Demo.DBLayer;
using System.Data;
using System.Data.SqlClient;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer
{
    class BLAccount
    {
        DBMain2 db = null;
        public BLAccount()
        {
            db = new DBMain2();
        }
        public DataSet LayAKH()
        {
            return db.ExecuteQueryDataSet("select * from TAIKHOANKH", CommandType.Text);
        }
        public DataSet LayAQL()
        {
            return db.ExecuteQueryDataSet("select * from TAIKHOANQL", CommandType.Text);
        }
        public DataSet LayANV()
        {
            return db.ExecuteQueryDataSet("select * from TAIKHOANNV", CommandType.Text);
        }
    }
}
