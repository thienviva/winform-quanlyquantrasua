﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using _ADO.NET_QuanLy_QuanTraSua_Demo.DBLayer;
using System.Data;
using System.Data.SqlClient;

namespace _ADO.NET_QuanLy_QuanTraSua_Demo.BSLayer
{
    class BLAccount_QL
    {
        DBMain db = null;
        public BLAccount_QL(string ID, string Pass)
        {
            db = new DBMain(ID, Pass);
        }
        public DataSet LayAQL()
        {
            return db.ExecuteQueryDataSet("select * from TAIKHOANQL", CommandType.Text);
        }
        public DataSet LayQL()
        {
            return db.ExecuteQueryDataSet("select * from QUANLY", CommandType.Text);
        }

        public DataSet LayANV()
        {
            return db.ExecuteQueryDataSet("select * from TAIKHOANNV", CommandType.Text);
        }
        public DataSet LayNV()
        {
            return db.ExecuteQueryDataSet("select * from NHANVIEN", CommandType.Text);
        }

        public DataSet LayMenu()
        {
            return db.ExecuteQueryDataSet("select * from MENU", CommandType.Text);
        }
        public bool ThemMonAn(string MaMon, int MaLoai, string TenMon, int Gia, int sldaban, ref string err)
        {
            string sqlString = "Insert Into MENU Values(" + "'" +
            MaMon + "',N'" +
            MaLoai + "',N'" +
            TenMon + "',N'" +
            Gia + "',N'" +
            sldaban + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
        public bool XoaMonAn(ref string err, string MaMon)
        {
            string sqlString = "Delete From MENU Where MaMon='" + MaMon + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }
        public bool CapNhatMonAn(string MaMon, int MaLoai, string TenMon, int Gia, int sldaban, ref string err)
        {
            string sqlString = "Update MENU Set MaLoai=N'" + MaLoai + "',"
            + "TenMon=N'" + TenMon + "',"
            + "Gia=N'" + Gia + "',"
            + "SoLuongDaBan=N'" + sldaban + "' Where MaMon='" + MaMon + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool XoaQL(ref string err, int MaQL)
        {
            string sqlString = "Exec XoaQuanLy " + MaQL;
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool XoaNV(ref string err, string MaNV)
        {
            string sqlString = "Delete From NHANVIEN Where MaNV='" + MaNV + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhatNV(int MaNV, string TenNV, string email, int Tuoi, string ChucVu, string SDT, string DiaChi, int MaCN, int Luong, ref string err)
        {
            string sqlString = "Update NHANVIEN Set TenNV=N'" + TenNV + "',"
            + "Email=N'" + email + "',"
            + "Tuoi=N'" + Tuoi + "',"
            + "ChucVu=N'" + ChucVu + "',"
            + "SDT=N'" + SDT + "',"
            + "DiaChi=N'" + DiaChi + "',"
            + "MaCN=N'" + MaCN + "',"
            + "Luong=N'" + Luong + "' Where MaNV='" + MaNV + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool CapNhatQL(int MaQL, string TenQL, string email, int Tuoi, string SDT, string DiaChi, int Luong, ref string err)
        {
            string sqlString = "Update QUANLY Set TenQL=N'" + TenQL + "',"
            + "Email=N'" + email + "',"
            + "Tuoi=N'" + Tuoi + "',"
            + "DiaChi=N'" + DiaChi + "',"
            + "SDT=N'" + SDT + "',"
            + "Luong=N'" + Luong + "' Where MaQL='" + MaQL + "'";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool ThemNV(int MaNV, string TenNV, string email, int Tuoi, string ChucVu, string SDT, string DiaChi, int MaCN, int Luong, ref string err)
        {
            string sqlString = "Insert Into NHANVIEN Values(N'"
            + MaNV + "',N'"
            + TenNV + "',N'"
            + email + "',N'"
            + Tuoi + "',N'"
            + ChucVu + "',N'"
            + SDT + "',N'"
            + DiaChi + "',N'"
            + MaCN + "',N'"
            + Luong + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public bool ThemQL(int MaQL, string TenQL, string email, int Tuoi, string SDT, string DiaChi, int Luong, ref string err)
        {
            string sqlString = "Insert Into QUANLY Values(N'"
            + MaQL + "',N'"
            + TenQL + "',N'"
            + email + "',N'"
            + Tuoi + "',N'"
            + DiaChi + "',N'"
            + SDT + "',N'"
            + Luong + "')";
            return db.MyExecuteNonQuery(sqlString, CommandType.Text, ref err);
        }

        public DataSet TimNV(string SearchStyle, string var)
        {
            if (SearchStyle == "Luong")
            {
                string sqlString = "Exec TimNV_Luong" + "'"+ var+"'";
                return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
            }
            else
            {
                string sqlString = "Select * from NHANVIEN Where " + SearchStyle + " LIKE N'%" + var + "%'";
                return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
            }
        }

        public DataSet TimQL(string SearchStyle, string var)
        {
            string sqlString = "Select * from QUANLY Where " + SearchStyle + " LIKE N'%" + var + "%'";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }

        public DataSet TimMonAn(string SearchStyle, string var)
        {
            string sqlString = "Select * from MENU Where " + SearchStyle + " LIKE N'%" + var + "%'";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }

        public DataSet TimMonAn_Gia(int gia)
        {
            string sqlString = "Exec TimMonAn_Gia" + gia ;
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }

        public DataSet TimNV_chiNhanh(int Search)
        {
            string sqlString = "select * from dbo.func_TimNV_ChiNhanh(" + Search + ")";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }

        public DataSet Tinh_TongLuongCN(int Search)
        {
            string sqlString = "select dbo.TongLuongCN(" + Search + ")";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }

        public DataSet Tinh_LuongTB_CN(int Search)
        {
            string sqlString = "select dbo.LuongTB_CN(" + Search + ")";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }

        public DataSet Top5Mon()
        {

            string sqlString = "Select * from  dbo.top5Mon_func()";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }
        public DataSet DSHoaDon()
        {
            string sqlString = "select * from DSHD";
            return db.ExecuteQueryDataSet(sqlString, CommandType.Text);
        }
    }
}
